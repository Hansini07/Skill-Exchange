import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Later: proxy API calls to Spring Boot to avoid CORS during development
  // server: { proxy: { "/api": "http://localhost:8080" } },
});
