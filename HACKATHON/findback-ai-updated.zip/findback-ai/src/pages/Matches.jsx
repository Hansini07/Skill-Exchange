import { useState } from "react";
import { getMatches } from "../utils/match";

function ItemBox({ title, item, color, open }) {
  return (
    <div className={`item-box ${color}`}>
      <div className="muted">{title}</div>
      <strong>{item.name}</strong>
      <p>"{item.description}"</p>
      {open && (
        <div className="details">
          <div>Category: {item.category}</div>
          <div>Location: {item.location}</div>
          <div>Date: {item.date}</div>
          {item.image && <img className="preview" src={item.image} alt={item.name} />}
        </div>
      )}
    </div>
  );
}

export default function Matches({ items, claims, onClaim }) {
  const [openId, setOpenId] = useState(null);
  const matches = getMatches(items);

  return (
    <div>
      <h1>AI Matches</h1>
      <p className="muted">Our AI compares lost and found reports and ranks the best matches.</p>
      {matches.length === 0 && (
        <div className="card empty">No matches yet. Report a lost item and a found item to see AI in action.</div>
      )}
      {matches.map(({ lost, found, score }) => {
        const key = `${lost.id}-${found.id}`;
        const claimed = claims.some((c) => c.lostId === lost.id && c.foundId === found.id && c.status !== "Rejected");
        return (
          <div className="card match" key={key}>
            <div className="match-top">
              <div className="score">AI Match Score: {score}%</div>
              <div className="bar"><div style={{ width: `${score}%` }} /></div>
            </div>
            <div className="match-items">
              <ItemBox title="Lost" item={lost} color="blue" open={openId === key} />
              <ItemBox title="Found" item={found} color="green" open={openId === key} />
            </div>
            <div className="actions">
              <button className="btn btn-light" onClick={() => setOpenId(openId === key ? null : key)}>
                {openId === key ? "Hide Details" : "View Details"}
              </button>
              <button className="btn btn-primary" disabled={claimed} onClick={() => onClaim(lost, found)}>
                {claimed ? "Claim Requested" : "Request Claim"}
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
