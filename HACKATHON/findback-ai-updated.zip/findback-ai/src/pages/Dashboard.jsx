import StatCard from "../components/StatCard";
import Badge from "../components/Badge";
import { getMatches } from "../utils/match";

export default function Dashboard({ items, claims, user }) {
  const recent = items.slice(0, 6);
  return (
    <div>
      <h1>Hi {user.name} 👋</h1>
      <p className="muted">Here's what's happening on campus.</p>
      <div className="grid">
        <StatCard icon="🔍" label="Total Lost Items" value={items.filter((i) => i.type === "lost").length} color="blue" />
        <StatCard icon="📦" label="Total Found Items" value={items.filter((i) => i.type === "found").length} color="green" />
        <StatCard icon="✨" label="Possible Matches" value={getMatches(items).length} color="blue" />
        <StatCard icon="⏳" label="Pending Claims" value={claims.filter((c) => c.status === "Pending").length} color="green" />
      </div>
      <h2>Recent items</h2>
      <div className="card list">
        {recent.map((i) => (
          <div className="list-row" key={i.id}>
            <div>
              <strong>{i.name}</strong>
              <div className="muted">{i.location} • {i.date}</div>
            </div>
            <div className="tags">
              <Badge text={i.type === "lost" ? "Lost" : "Found"} />
              {i.status === "Returned" && <Badge text="Returned" />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
