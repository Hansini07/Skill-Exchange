import Badge from "../components/Badge";

export default function Claims({ claims }) {
  return (
    <div>
      <h1>My Claims</h1>
      <p className="muted">Track the status of your claim requests.</p>
      <div className="card table-wrap">
        <table>
          <thead>
            <tr><th>Item</th><th>Claim Date</th><th>Status</th></tr>
          </thead>
          <tbody>
            {claims.map((c) => (
              <tr key={c.id}>
                <td>{c.itemName}</td>
                <td>{c.date}</td>
                <td><Badge text={c.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
