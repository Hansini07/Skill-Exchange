import StatCard from "../components/StatCard";
import Badge from "../components/Badge";

export default function Admin({ items, claims, onUpdateClaim }) {
  const count = (s) => claims.filter((c) => c.status === s).length;
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <p className="muted">Review claims and mark items as returned.</p>
      <div className="grid">
        <StatCard icon="📊" label="Total Reports" value={items.length} color="blue" />
        <StatCard icon="🔍" label="Lost Items" value={items.filter((i) => i.type === "lost").length} color="blue" />
        <StatCard icon="📦" label="Found Items" value={items.filter((i) => i.type === "found").length} color="green" />
        <StatCard icon="⏳" label="Pending Claims" value={count("Pending")} color="green" />
        <StatCard icon="✅" label="Returned Items" value={count("Returned")} color="blue" />
      </div>
      <h2>Claim requests</h2>
      <div className="card table-wrap">
        <table>
          <thead>
            <tr><th>Item</th><th>Date</th><th>Status</th><th>Action</th></tr>
          </thead>
          <tbody>
            {claims.map((c) => (
              <tr key={c.id}>
                <td>{c.itemName}</td>
                <td>{c.date}</td>
                <td><Badge text={c.status} /></td>
                <td>
                  <div className="actions">
                    {c.status === "Pending" && (
                      <>
                        <button className="btn btn-primary small" onClick={() => onUpdateClaim(c.id, "Approved")}>Approve</button>
                        <button className="btn btn-danger small" onClick={() => onUpdateClaim(c.id, "Rejected")}>Reject</button>
                      </>
                    )}
                    {c.status === "Approved" && (
                      <button className="btn btn-green small" onClick={() => onUpdateClaim(c.id, "Returned")}>Mark Returned</button>
                    )}
                    {(c.status === "Rejected" || c.status === "Returned") && <span className="muted">—</span>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
