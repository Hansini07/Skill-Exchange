import { useState } from "react";

export default function Login({ onLogin }) {
  const [register, setRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("student@college.edu");
  const [password, setPassword] = useState("password");

  const submit = (e) => {
    e.preventDefault();
    onLogin({ name: name || "Student", email }); // mock login: any input works
  };

  return (
    <div className="login-wrap">
      <form className="card login" onSubmit={submit}>
        <div className="brand">Find<span>Back</span> AI</div>
        <p className="muted">Intelligent campus lost & found</p>
        <h2>{register ? "Create account" : "Welcome back"}</h2>
        {register && (
          <label>Full name
            <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
          </label>
        )}
        <label>Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>Password
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <button className="btn btn-primary" type="submit">{register ? "Register" : "Login"}</button>
        <p className="muted center">
          {register ? "Already have an account?" : "New here?"}{" "}
          <a href="#" onClick={(e) => { e.preventDefault(); setRegister(!register); }}>
            {register ? "Login" : "Register"}
          </a>
        </p>
      </form>
    </div>
  );
}
