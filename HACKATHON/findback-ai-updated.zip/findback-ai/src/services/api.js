// Future Spring Boot connection. Not used yet: the app runs on mock data in App.jsx.
const BASE = import.meta.env.VITE_API_URL || "http://localhost:8080/api";

const request = async (path, options = {}) => {
  const token = localStorage.getItem("token");
  const res = await fetch(BASE + path, {
    headers: { "Content-Type": "application/json", ...(token && { Authorization: `Bearer ${token}` }) },
    ...options,
  });
  if (!res.ok) throw new Error("Request failed: " + res.status);
  return res.json();
};

export const login = (email, password) => request("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
export const getItems = () => request("/items");
export const reportItem = (item) => request("/items", { method: "POST", body: JSON.stringify(item) });
export const getMatches = () => request("/matches");
export const requestClaim = (lostId, foundId) => request("/claims", { method: "POST", body: JSON.stringify({ lostId, foundId }) });
export const getClaims = () => request("/claims");
export const updateClaim = (id, status) => request(`/admin/claims/${id}`, { method: "PUT", body: JSON.stringify({ status }) });
