// Mock data. Replace with API calls to Spring Boot later (see services/api.js).
export const today = new Date().toISOString().slice(0, 10);

export const categories = ["Wallet", "Phone", "Keys", "ID Card", "Bag", "Electronics", "Books", "Other"];

export const initialItems = [
  { id: 1, type: "lost", name: "Blue Water Bottle", category: "Other", description: "Blue steel bottle left in cafeteria", location: "Cafeteria", date: "2026-10-26", image: "", status: "Open" },
  { id: 2, type: "lost", name: "Scientific Calculator", category: "Electronics", description: "Casio calculator with initials on the back", location: "Block B", date: "2026-10-27", image: "", status: "Open" },
  { id: 3, type: "found", name: "Silver Keys", category: "Keys", description: "Bunch of keys with a red keychain", location: "Main Gate", date: "2026-10-25", image: "", status: "Returned" },
  { id: 4, type: "found", name: "Grey Backpack", category: "Bag", description: "Grey backpack with a laptop sleeve", location: "Sports Ground", date: "2026-10-28", image: "", status: "Open" },
];

export const initialClaims = [
  { id: 101, itemName: "Silver Keys", date: "2026-10-24", status: "Returned" },
  { id: 102, itemName: "Grey Backpack", date: "2026-10-28", status: "Pending" },
];

export const demoForms = {
  lost: { name: "Black Wallet", category: "Wallet", description: "Black wallet with college ID near library", location: "Library" },
  found: { name: "Black Leather Wallet", category: "Wallet", description: "Black leather wallet with student ID near library", location: "Library" },
};
