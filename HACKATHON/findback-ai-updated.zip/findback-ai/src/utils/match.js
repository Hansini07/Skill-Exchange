// Mock "AI" matcher: keyword overlap + category bonus.
// Demo wallet pair scores 92%. Replace with the real AI endpoint later.
const stop = new Set(["a", "an", "the", "with", "near", "in", "at", "of", "and", "my", "on", "is", "to", "for", "by"]);

const words = (i) =>
  new Set(
    `${i.name} ${i.description} ${i.location}`
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter((w) => w && !stop.has(w))
  );

export function matchScore(lost, found) {
  const b = words(found);
  let shared = 0;
  words(lost).forEach((w) => b.has(w) && shared++);
  return Math.min(98, 30 + shared * 12 + (lost.category === found.category ? 14 : 0));
}

export function getMatches(items) {
  const open = items.filter((i) => i.status === "Open");
  const pairs = [];
  open.filter((i) => i.type === "lost").forEach((l) =>
    open.filter((i) => i.type === "found").forEach((f) => {
      const score = matchScore(l, f);
      if (score >= 60) pairs.push({ lost: l, found: f, score });
    })
  );
  return pairs.sort((a, b) => b.score - a.score);
}
