import { useState } from "react";
import { categories, today, demoForms } from "../data/mockData";

export default function ReportForm({ type, onSubmit }) {
  const blank = { name: "", category: "Wallet", description: "", location: "", date: today, image: "" };
  const [f, setF] = useState(blank);
  const isLost = type === "lost";

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const pickImage = (e) => {
    const file = e.target.files[0];
    if (file) setF({ ...f, image: URL.createObjectURL(file) });
  };
  const submit = (e) => {
    e.preventDefault();
    onSubmit({ ...f, type });
    setF(blank);
  };

  return (
    <div>
      <h1>{isLost ? "Report Lost Item" : "Report Found Item"}</h1>
      <p className="muted">
        {isLost ? "Tell us what you lost and we'll look for matches." : "Tell us what you found so the owner can claim it."}
      </p>
      <form className="card form" onSubmit={submit}>
        <button type="button" className="btn btn-light" onClick={() => setF({ ...f, ...demoForms[type] })}>
          ⚡ Fill demo data
        </button>
        <label>Item Name
          <input required value={f.name} onChange={set("name")} placeholder="e.g. Black Wallet" />
        </label>
        <label>Category
          <select value={f.category} onChange={set("category")}>
            {categories.map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        <label>Description
          <textarea required rows="3" value={f.description} onChange={set("description")} placeholder="Colour, brand, marks, what's inside..." />
        </label>
        <div className="row">
          <label>Location
            <input required value={f.location} onChange={set("location")} placeholder="e.g. Library" />
          </label>
          <label>Date
            <input type="date" required value={f.date} onChange={set("date")} />
          </label>
        </div>
        <label>Upload Image
          <input type="file" accept="image/*" onChange={pickImage} />
        </label>
        {f.image && <img className="preview" src={f.image} alt="Preview" />}
        <button className="btn btn-primary" type="submit">{isLost ? "Submit Lost Report" : "Submit Found Report"}</button>
      </form>
    </div>
  );
}
