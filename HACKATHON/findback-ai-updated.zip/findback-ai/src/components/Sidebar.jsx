const links = [
  ["dashboard", "🏠", "Dashboard"],
  ["lost", "🔍", "Report Lost"],
  ["found", "📦", "Report Found"],
  ["matches", "✨", "AI Matches"],
  ["claims", "📋", "My Claims"],
  ["admin", "🛡️", "Admin"],
];

export default function Sidebar({ page, setPage, onLogout }) {
  return (
    <aside className="sidebar">
      <div className="brand">Find<span>Back</span> AI</div>
      <nav>
        {links.map(([key, icon, label]) => (
          <button key={key} className={page === key ? "nav active" : "nav"} onClick={() => setPage(key)}>
            <span>{icon}</span> {label}
          </button>
        ))}
        <button className="nav logout" onClick={onLogout}><span>🚪</span> Logout</button>
      </nav>
    </aside>
  );
}
