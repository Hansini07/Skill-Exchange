export default function StatCard({ icon, label, value, color = "blue" }) {
  return (
    <div className="card stat">
      <div className={`stat-icon ${color}`}>{icon}</div>
      <div>
        <div className="stat-value">{value}</div>
        <div className="muted">{label}</div>
      </div>
    </div>
  );
}
