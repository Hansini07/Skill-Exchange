import { useState } from "react";
import Sidebar from "./components/Sidebar";
import ReportForm from "./components/ReportForm";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Matches from "./pages/Matches";
import Claims from "./pages/Claims";
import Admin from "./pages/Admin";
import { initialItems, initialClaims, today } from "./data/mockData";

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [items, setItems] = useState(initialItems);
  const [claims, setClaims] = useState(initialClaims);
  const [toast, setToast] = useState("");

  const notify = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  };

  // Report lost/found -> next step of the demo flow
  const addItem = (item) => {
    setItems([{ ...item, id: Date.now(), status: "Open" }, ...items]);
    notify(item.type === "lost" ? "Lost item reported!" : "Found item reported! Checking AI matches...");
    setPage(item.type === "lost" ? "found" : "matches");
  };

  const requestClaim = (lost, found) => {
    setClaims([{ id: Date.now(), lostId: lost.id, foundId: found.id, itemName: lost.name, date: today, status: "Pending" }, ...claims]);
    notify("Claim requested!");
    setPage("claims");
  };

  const updateClaim = (id, status) => {
    const claim = claims.find((c) => c.id === id);
    setClaims(claims.map((c) => (c.id === id ? { ...c, status } : c)));
    if (status === "Returned") {
      setItems(items.map((i) => (i.id === claim.lostId || i.id === claim.foundId ? { ...i, status: "Returned" } : i)));
    }
    notify(`Claim ${status.toLowerCase()}`);
  };

  if (!user) return <Login onLogin={(u) => { setUser(u); setPage("dashboard"); }} />;

  return (
    <div className="app">
      <Sidebar page={page} setPage={setPage} onLogout={() => setUser(null)} />
      <main className="content">
        {page === "dashboard" && <Dashboard items={items} claims={claims} user={user} />}
        {page === "lost" && <ReportForm type="lost" onSubmit={addItem} />}
        {page === "found" && <ReportForm type="found" onSubmit={addItem} />}
        {page === "matches" && <Matches items={items} claims={claims} onClaim={requestClaim} />}
        {page === "claims" && <Claims claims={claims} />}
        {page === "admin" && <Admin items={items} claims={claims} onUpdateClaim={updateClaim} />}
      </main>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
