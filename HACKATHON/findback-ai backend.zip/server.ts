import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const findBackServerPath = path.join(__dirname, 'FindBack_AI', 'server.js');
const { startServer } = require(findBackServerPath);

const PORT = Number(process.env.PORT) || 3000;
startServer(PORT);
