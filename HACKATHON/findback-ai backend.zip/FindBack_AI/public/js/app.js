/**
 * FindBack AI — Client-Side UI Controller
 * Handles Light/Dark theme persistence, loading states, image upload previews,
 * toast notifications, demo quick-fill, live TF-IDF sandbox, and iframe token continuity.
 */

(function () {
  // 1. Theme Toggle Logic
  function updateThemeIcons(theme) {
    document.querySelectorAll('[data-theme-toggle]').forEach((btn) => {
      const sun = btn.querySelector('.icon-sun');
      const moon = btn.querySelector('.icon-moon');
      if (sun && moon) {
        sun.style.display = theme === 'dark' ? 'inline-block' : 'none';
        moon.style.display = theme === 'dark' ? 'none' : 'inline-block';
      }
      btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    });
  }

  function setTheme(nextTheme) {
    document.documentElement.setAttribute('data-theme', nextTheme);
    document.documentElement.setAttribute('data-bs-theme', nextTheme);
    try {
      localStorage.setItem('fb_theme', nextTheme);
    } catch (_e) {}
    updateThemeIcons(nextTheme);
  }

  document.addEventListener('DOMContentLoaded', () => {
    const activeTheme = document.documentElement.getAttribute('data-theme') || 'light';
    updateThemeIcons(activeTheme);

    document.querySelectorAll('[data-theme-toggle]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme') || 'light';
        setTheme(current === 'dark' ? 'light' : 'dark');
      });
    });

    // 2. Cross-Origin Preview Iframe Session Token Continuity
    // On localhost:3000 cookies work natively; inside strict third-party-cookie-blocked iframes,
    // we seamlessly carry the signed session token across internal navigation and forms.
    const urlParams = new URLSearchParams(window.location.search);
    const queryToken = urlParams.get('_ft');
    const serverToken = window.__FB_AUTH_TOKEN || '';

    if (window.location.pathname === '/login' && !serverToken) {
      try {
        sessionStorage.removeItem('fb_auth_token');
      } catch (_e) {}
    } else if (serverToken || queryToken) {
      try {
        sessionStorage.setItem('fb_auth_token', serverToken || queryToken);
      } catch (_e) {}
    }

    let activeToken = serverToken;
    if (!activeToken) {
      try {
        activeToken = sessionStorage.getItem('fb_auth_token') || '';
      } catch (_e) {}
    }

    const inIframe = window.self !== window.top;
    if (inIframe && activeToken) {
      document.querySelectorAll('a[href^="/"]').forEach((anchor) => {
        const href = anchor.getAttribute('href');
        if (!href || href.startsWith('/auth/logout') || href.startsWith('/FindBack_AI') || href.startsWith('/download')) {
          return;
        }
        if (!href.includes('_ft=')) {
          const [basePath, hash] = href.split('#');
          const sep = basePath.includes('?') ? '&' : '?';
          anchor.setAttribute('href', `${basePath}${sep}_ft=${encodeURIComponent(activeToken)}${hash ? '#' + hash : ''}`);
        }
      });

      document.querySelectorAll('form').forEach((form) => {
        const action = form.getAttribute('action') || window.location.pathname;
        if (action.includes('/auth/logout')) return;
        const method = (form.getAttribute('method') || 'GET').toUpperCase();
        if (!form.querySelector('input[name="_ft"]')) {
          const hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = '_ft';
          hidden.value = activeToken;
          form.appendChild(hidden);
        }
        // For multipart/form-data forms, query string is parsed before multer runs
        if (method === 'POST' && !action.includes('_ft=')) {
          const sep = action.includes('?') ? '&' : '?';
          form.setAttribute('action', `${action}${sep}_ft=${encodeURIComponent(activeToken)}`);
        }
      });
    }

    // Clear session token on logout click
    document.querySelectorAll('a[href*="/auth/logout"], form[action*="/auth/logout"]').forEach((el) => {
      el.addEventListener('click', () => {
        try {
          sessionStorage.removeItem('fb_auth_token');
        } catch (_e) {}
      });
    });

    // 3. Form Submit Loading Indicators
    document.querySelectorAll('form[data-loading]').forEach((form) => {
      form.addEventListener('submit', () => {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn && !submitBtn.disabled) {
          const loadingLabel = submitBtn.getAttribute('data-loading-text') || 'Processing...';
          submitBtn.disabled = true;
          submitBtn.innerHTML =
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' +
            loadingLabel;
        }
      });
    });

    // 4. Local Image Upload Preview & Client Validation
    const imageInputs = document.querySelectorAll('input[type="file"][data-image-preview]');
    imageInputs.forEach((input) => {
      input.addEventListener('change', (e) => {
        const previewId = input.getAttribute('data-image-preview');
        const container = document.getElementById(previewId);
        if (!container) return;

        const file = e.target.files && e.target.files[0];
        if (!file) {
          container.classList.add('d-none');
          return;
        }

        if (file.size > 5 * 1024 * 1024) {
          input.value = '';
          container.classList.remove('d-none');
          container.innerHTML = '<p class="text-danger small mb-0">File exceeds 5MB limit. Please choose a smaller photo.</p>';
          return;
        }

        const reader = new FileReader();
        reader.onload = (ev) => {
          container.classList.remove('d-none');
          container.innerHTML = `
            <div class="d-flex align-items-center gap-3 p-2 rounded border" style="border-color: var(--fb-border);">
              <img src="${ev.target.result}" alt="Selected item preview" style="width: 72px; height: 54px; object-fit: cover; border-radius: 6px;" />
              <div class="small">
                <div class="fw-semibold text-truncate" style="max-width: 220px;">${file.name}</div>
                <div class="text-secondary fb-mono">${(file.size / 1024).toFixed(1)} KB · Ready to upload</div>
              </div>
            </div>
          `;
        };
        reader.readAsDataURL(file);
      });
    });

    // 5. Auto-Dismiss Toast Notifications
    const toastEl = document.getElementById('fbToast');
    if (toastEl) {
      const closeBtn = toastEl.querySelector('[data-toast-close]');
      const dismiss = () => {
        toastEl.style.opacity = '0';
        toastEl.style.transform = 'translateY(8px)';
        setTimeout(() => toastEl.remove(), 200);
      };
      if (closeBtn) closeBtn.addEventListener('click', dismiss);
      setTimeout(dismiss, 5500);
    }

    // 6. Demo Account Quick-Fill Buttons on Login Page
    document.querySelectorAll('[data-demo-email]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const email = btn.getAttribute('data-demo-email');
        const password = btn.getAttribute('data-demo-password');
        const portal = btn.getAttribute('data-demo-portal') || 'STUDENT';
        const emailField = document.getElementById('loginEmail');
        const passField = document.getElementById('loginPassword');
        const portalField = document.getElementById('loginPortal');
        if (emailField) emailField.value = email;
        if (passField) passField.value = password;
        if (portalField) portalField.value = portal;
      });
    });

    // 7. Live TF-IDF Similarity Sandbox on Landing Page
    const sandboxForm = document.getElementById('tfidfSandboxForm');
    if (sandboxForm) {
      sandboxForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = sandboxForm.querySelector('button[type="submit"]');
        const out = document.getElementById('sandboxResult');
        const origHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Computing TF-IDF...';

        const formData = new FormData(sandboxForm);
        const payload = Object.fromEntries(formData.entries());

        try {
          const resp = await fetch('/api/match-sandbox', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          const data = await resp.json();
          if (data.ok && out) {
            out.classList.remove('d-none');
            const kw =
              data.factors.sharedKeywords && data.factors.sharedKeywords.length
                ? data.factors.sharedKeywords.join(' · ')
                : 'None detected';
            out.innerHTML = `
              <div class="pt-3 mt-3" style="border-top: 1px solid var(--fb-border);">
                <div class="d-flex flex-wrap align-items-baseline justify-content-between gap-2 mb-2">
                  <span class="fw-semibold">Computed Similarity Score</span>
                  <span class="fb-mono fs-4 fw-bold" style="color: ${data.score >= 70 ? 'var(--fb-success)' : 'var(--fb-primary)'};">${data.score}%</span>
                </div>
                <div class="fb-score-meter mb-3">
                  <div class="fb-score-fill ${data.score >= 70 ? 'high' : ''}" style="width: ${Math.min(100, data.score)}%;"></div>
                </div>
                <div class="fb-meta-line mb-2">
                  <span>TF-IDF Text: <strong class="fb-mono">${data.factors.textSimilarity}%</strong></span>
                  <span>·</span>
                  <span>Category: <strong class="fb-mono">${data.factors.categoryMatch}%</strong></span>
                  <span>·</span>
                  <span>Color: <strong class="fb-mono">${data.factors.colorMatch}%</strong></span>
                  <span>·</span>
                  <span>Location: <strong class="fb-mono">${data.factors.locationProximity}%</strong></span>
                </div>
                <div class="small text-secondary">Shared Stemmed Tokens: <span class="fb-mono">${kw}</span></div>
              </div>
            `;
          }
        } catch (_err) {
          if (out) {
            out.classList.remove('d-none');
            out.innerHTML = '<p class="text-danger small mt-2 mb-0">Could not calculate similarity right now.</p>';
          }
        } finally {
          btn.disabled = false;
          btn.innerHTML = origHtml;
        }
      });
    }
  });
})();
