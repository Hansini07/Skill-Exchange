# FindBack AI

**Intelligent Campus Lost & Found & Smart Item Matching System**

FindBack AI is a full-stack campus lost-and-found web platform built with **Node.js, Express.js, SQLite (`better-sqlite3`), EJS, and Bootstrap 5**. It features a purely local **JavaScript Information Retrieval & Smart Matching Engine** powered by **TF-IDF vectorization, Cosine Similarity, and Multi-Attribute Weighted Scoring** — requiring zero external AI APIs or cloud services.

---

## Key Features

1. **Local JavaScript AI Matching Engine (`src/matcher.js`)**
   - Text preprocessing, campus synonym canonicalization, plural/suffix stemming, tokenization, and stopword removal
   - Corpus-wide **TF-IDF** vectorization across all SQLite item reports
   - Mathematical **Cosine Similarity** paired with structured attribute scoring (Category, Color family, Brand similarity, Campus Zone/Location proximity, and Chronological Date proximity)
   - Transparent explainability breakdown (0–100 score + shared keywords + factor percentages)
   - Automatic matching whenever a new Lost or Found report is submitted

2. **Role-Based Authentication & Session Security**
   - Student registration & login, dedicated Admin verification access
   - `bcrypt` salted password hashing + persistent SQLite-backed `express-session` store
   - Protected student & admin routes

3. **Lost & Found Reporting with Local Image Uploads**
   - Validated forms with `multer` local image storage (`public/uploads/`)
   - Duplicate report prevention via content fingerprinting

4. **Verified Claim Lifecycle**
   - Students submit ownership claims with proof details (`PENDING` -> `APPROVED` / `REJECTED` -> `COMPLETED`)
   - AI matches never auto-approve claims; only verified Admins approve/reject claims and mark items returned

5. **Database-Backed Notifications & Audit Logs**
   - Real-time unread notification badges for report submissions, discovered AI matches, claim status updates, and item handovers
   - Complete Admin console with system metrics, user management, match review, claim verification, and activity audit logs

---

## Quick Start (Windows / macOS / Linux in VS Code)

### Prerequisites
- **Node.js v18+** (v20 or v22 recommended) installed on your machine.

### 1. Open Folder in VS Code
Extract `FindBack_AI_Hackathon.zip` and open the `FindBack_AI` folder directly in VS Code.

### 2. Install Dependencies
Open the VS Code terminal (`Ctrl + ~`) and run:

```bash
npm install
```

### 3. Start the Application
```bash
npm start
```

The SQLite database (`./data/findback.sqlite`), tables, indexes, and rich demo dataset (1 Admin, 10 Students, 15 Lost items, 15 Found items, live AI matches, and sample claims) are **automatically initialized** on first startup.

### 4. Open in Browser
Visit:
```text
http://localhost:3000
```

---

## Demo Credentials

### Administrator Account
- **Email:** `admin@findback.ai`
- **Password:** `Admin@123`

### Demo Student Accounts (All use password `Student@123`)
- **Student A (Lost Black Wallet Scenario):** `aarav.sharma@campus.edu` / `Student@123`
- **Student B (Found Black Wallet Scenario):** `priya.patel@campus.edu` / `Student@123`
- **Student C (Completed Bottle Return Scenario):** `rohan.verma@campus.edu` / `Student@123`
- **Additional Students:** `ananya.iyer@campus.edu`, `vikram.nair@campus.edu`, `neha.gupta@campus.edu`, `kabir.mehta@campus.edu`, `ishita.rao@campus.edu`, `arjun.desai@campus.edu`, `meera.krishnan@campus.edu`

---

## Project Structure

```text
FindBack_AI/
├── server.js                  # Express app entry point & middleware setup
├── package.json               # Dependencies & npm scripts
├── README.md                  # Setup & architecture documentation
├── .env.example               # Environment configuration template
├── .gitignore
├── src/
│   ├── db.js                  # SQLite initialization, schema, indexes & seed data
│   ├── matcher.js             # Local TF-IDF + Cosine Similarity + Weighted AI Matcher
│   ├── middleware/
│   │   ├── auth.js            # Session & role-based route protection
│   │   └── upload.js          # Multer image validation & storage config
│   ├── routes/
│   │   ├── pageRoutes.js      # EJS view routes
│   │   ├── authRoutes.js      # Login, register, logout, profile update routes
│   │   ├── itemRoutes.js      # Lost & found submission & status routes
│   │   ├── claimRoutes.js     # Ownership claim submission routes
│   │   └── adminRoutes.js     # Admin claim review, user toggle & return routes
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── itemController.js
│   │   ├── claimController.js
│   │   └── adminController.js
│   └── services/
│       └── notificationService.js
├── views/                     # EJS server-rendered templates & partials
├── public/                    # Static CSS, client JS, demo images & uploads
└── data/                      # Auto-created SQLite database directory
```
