require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const session = require('express-session');

const { db, SQLiteSessionStore, initializeDatabase } = require('./src/db');
const { attachLocals } = require('./src/middleware/auth');

const pageRoutes = require('./src/routes/pageRoutes');
const authRoutes = require('./src/routes/authRoutes');
const itemRoutes = require('./src/routes/itemRoutes');
const claimRoutes = require('./src/routes/claimRoutes');
const adminRoutes = require('./src/routes/adminRoutes');

// Initialize SQLite database, tables, indexes, and demo data automatically
initializeDatabase();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Support reverse proxies (e.g. cloud containers) while working seamlessly on localhost HTTP
app.set('trust proxy', 1);

// Configure EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Body parsers & static assets
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Dynamic Express Session middleware with SQLite persistence
const sessionStore = new SQLiteSessionStore(db);
const baseSessionMiddleware = session({
  name: 'findback.sid',
  secret: process.env.SESSION_SECRET || 'findback-ai-campus-hackathon-secret-2026',
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
  }
});

app.use((req, res, next) => {
  baseSessionMiddleware(req, res, () => {
    if (req.session && req.session.cookie) {
      const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
      if (isHttps) {
        req.session.cookie.secure = true;
        req.session.cookie.sameSite = 'none';
        req.session.cookie.partitioned = true;
      } else {
        req.session.cookie.secure = false;
        req.session.cookie.sameSite = 'lax';
      }
    }
    next();
  });
});

// Attach current user, toast notifications, and unread counters to EJS locals
app.use(attachLocals);

// Serve downloadable Hackathon ZIP package if present
app.get(['/FindBack_AI_Hackathon.zip', '/download-source'], (_req, res) => {
  const candidates = [
    path.resolve(__dirname, '../FindBack_AI_Hackathon.zip'),
    path.resolve(__dirname, 'FindBack_AI_Hackathon.zip')
  ];
  const foundZip = candidates.find((p) => fs.existsSync(p));
  if (!foundZip) {
    return res.status(404).send('Source ZIP archive is currently being prepared.');
  }
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="FindBack_AI_Hackathon.zip"');
  return res.sendFile(foundZip);
});

// Application Routes
app.use('/auth', authRoutes);
app.use('/items', itemRoutes);
app.use('/claims', claimRoutes);
app.use('/admin', adminRoutes);
app.use('/', pageRoutes);

// 404 Handler
app.use((req, res) => {
  res.status(404).render('index', {
    pageTitle: 'Page Not Found — FindBack AI',
    stats: {
      totalLost: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'LOST'").get().c,
      totalFound: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'FOUND'").get().c,
      totalMatches: db.prepare('SELECT COUNT(*) as c FROM matches').get().c,
      totalReturned: db.prepare("SELECT COUNT(*) as c FROM items WHERE status = 'RETURNED' AND type = 'FOUND'").get().c,
      totalStudents: db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'STUDENT'").get().c
    },
    recentItems: [],
    featuredMatches: [],
    toast: {
      type: 'error',
      message: `Page "${req.originalUrl}" was not found. Redirected to home.`
    }
  });
});

// Global Error Handler
app.use((err, _req, res, _next) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).send('Internal Server Error. Please try refreshing the page.');
});

function startServer(port = PORT) {
  return app.listen(port, '0.0.0.0', () => {
    console.log(`FindBack AI running at http://localhost:${port}`);
  });
}

if (require.main === module) {
  startServer(PORT);
}

module.exports = { app, startServer };
