const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const {
  submitClaim,
  markNotificationRead,
  markAllNotificationsRead
} = require('../controllers/claimController');

router.post('/', requireAuth, submitClaim);
router.post('/notifications/:id/read', requireAuth, markNotificationRead);
router.post('/notifications/read-all', requireAuth, markAllNotificationsRead);

module.exports = router;
