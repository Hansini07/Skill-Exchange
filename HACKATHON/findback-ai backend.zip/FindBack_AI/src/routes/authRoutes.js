const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const {
  registerStudent,
  loginUser,
  logoutUser,
  updateProfile
} = require('../controllers/authController');

router.post('/register', registerStudent);
router.post('/login', loginUser);
router.post('/logout', logoutUser);
router.get('/logout', logoutUser);
router.post('/profile', requireAuth, updateProfile);

module.exports = router;
