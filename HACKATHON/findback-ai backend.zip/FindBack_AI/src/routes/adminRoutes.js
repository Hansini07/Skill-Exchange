const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const {
  reviewClaim,
  markClaimReturned,
  dismissMatch,
  rerunMatchingEngine,
  toggleUserStatus
} = require('../controllers/adminController');

router.use(requireAdmin);

router.post('/claims/:id/review', reviewClaim);
router.post('/claims/:id/return', markClaimReturned);
router.post('/matches/:id/dismiss', dismissMatch);
router.post('/matches/rerun', rerunMatchingEngine);
router.post('/users/:id/toggle', toggleUserStatus);

module.exports = router;
