const express = require('express');
const router = express.Router();
const { requireAuth, setFlashRedirect } = require('../middleware/auth');
const { uploadItemImage } = require('../middleware/upload');
const {
  submitLostItem,
  submitFoundItem,
  archiveOwnItem
} = require('../controllers/itemController');

function handleUpload(routePath) {
  return (req, res, next) => {
    uploadItemImage.single('image')(req, res, (err) => {
      if (err) {
        return setFlashRedirect(req, res, routePath, err.message || 'Image upload failed.', 'error');
      }
      next();
    });
  };
}

router.post('/lost', requireAuth, handleUpload('/report-lost'), submitLostItem);
router.post('/found', requireAuth, handleUpload('/report-found'), submitFoundItem);
router.post('/:id/archive', requireAuth, archiveOwnItem);

module.exports = router;
