const express = require('express');
const router = express.Router();
const { db } = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { VALID_CATEGORIES } = require('../controllers/itemController');
const { calculateItemSimilarity, computeCorpusIdf, preprocessAndTokenize } = require('../matcher');

// Public Landing Page
router.get('/', (req, res) => {
  const stats = {
    totalLost: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'LOST' AND status != 'ARCHIVED'").get().c,
    totalFound: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'FOUND' AND status != 'ARCHIVED'").get().c,
    totalMatches: db.prepare("SELECT COUNT(*) as c FROM matches WHERE status != 'DISMISSED'").get().c,
    totalReturned: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'FOUND' AND status = 'RETURNED'").get().c,
    totalStudents: db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'STUDENT'").get().c
  };

  const recentItems = db
    .prepare(
      `SELECT i.*, u.full_name AS reporter_name, u.department AS reporter_dept
       FROM items i
       JOIN users u ON u.id = i.user_id
       WHERE i.status != 'ARCHIVED'
       ORDER BY i.created_at DESC
       LIMIT 6`
    )
    .all();

  const featuredMatches = db
    .prepare(
      `SELECT m.*,
              l.item_name AS lost_name, l.description AS lost_desc, l.location AS lost_location, l.color AS lost_color, l.category AS lost_category, l.image_path AS lost_image,
              f.item_name AS found_name, f.description AS found_desc, f.location AS found_location, f.color AS found_color, f.category AS found_category, f.image_path AS found_image
       FROM matches m
       JOIN items l ON l.id = m.lost_item_id
       JOIN items f ON f.id = m.found_item_id
       WHERE m.status != 'DISMISSED'
       ORDER BY m.similarity_score DESC
       LIMIT 3`
    )
    .all()
    .map((m) => ({
      ...m,
      factors: JSON.parse(m.matching_factors || '{}')
    }));

  res.render('index', {
    pageTitle: 'FindBack AI — Intelligent Campus Lost & Found',
    stats,
    recentItems,
    featuredMatches
  });
});

// Login Page
router.get('/login', (req, res) => {
  if (req.currentUser) {
    return res.redirect(req.currentUser.role === 'ADMIN' ? '/admin' : '/dashboard');
  }
  const activePortal = req.query.role === 'admin' ? 'ADMIN' : 'STUDENT';
  res.render('login', {
    pageTitle: 'Sign In — FindBack AI',
    activePortal
  });
});

// Register Page
router.get('/register', (req, res) => {
  if (req.currentUser) {
    return res.redirect(req.currentUser.role === 'ADMIN' ? '/admin' : '/dashboard');
  }
  res.render('register', {
    pageTitle: 'Student Registration — FindBack AI'
  });
});

// Public / Campus-Wide Explore Items Page
router.get('/browse-items', (req, res) => {
  const q = (req.query.q || '').trim();
  const type = (req.query.type || 'ALL').toUpperCase();
  const category = (req.query.category || 'ALL').trim();
  const status = (req.query.status || 'ALL').toUpperCase();

  let sql = `
    SELECT i.*, u.full_name AS reporter_name, u.department AS reporter_dept,
           (SELECT MAX(similarity_score) FROM matches m WHERE m.lost_item_id = i.id OR m.found_item_id = i.id) AS top_match_score
    FROM items i
    JOIN users u ON u.id = i.user_id
    WHERE i.status != 'ARCHIVED'
  `;
  const params = [];

  if (type === 'LOST' || type === 'FOUND') {
    sql += ' AND i.type = ?';
    params.push(type);
  }

  if (category && category !== 'ALL') {
    sql += ' AND i.category = ?';
    params.push(category);
  }

  if (['OPEN', 'MATCHED', 'CLAIMED', 'RETURNED'].includes(status)) {
    sql += ' AND i.status = ?';
    params.push(status);
  }

  if (q) {
    sql += ' AND (i.item_name LIKE ? OR i.description LIKE ? OR i.location LIKE ? OR i.brand LIKE ? OR i.color LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like, like);
  }

  sql += ' ORDER BY i.created_at DESC';

  const items = db.prepare(sql).all(...params);

  res.render('browse-items', {
    pageTitle: 'Explore Campus Items — FindBack AI',
    items,
    categories: VALID_CATEGORIES,
    filters: { q, type, category, status }
  });
});

// Student Dashboard
router.get('/dashboard', requireAuth, (req, res) => {
  const userId = req.currentUser.id;

  const myLostItems = db
    .prepare("SELECT * FROM items WHERE user_id = ? AND type = 'LOST' AND status != 'ARCHIVED' ORDER BY created_at DESC")
    .all(userId);

  const myFoundItems = db
    .prepare("SELECT * FROM items WHERE user_id = ? AND type = 'FOUND' AND status != 'ARCHIVED' ORDER BY created_at DESC")
    .all(userId);

  const myMatches = db
    .prepare(
      `SELECT m.*,
              l.item_name AS lost_name, l.location AS lost_location, l.event_date AS lost_date, l.user_id AS lost_user_id, l.color AS lost_color, l.image_path AS lost_image,
              f.item_name AS found_name, f.location AS found_location, f.event_date AS found_date, f.user_id AS found_user_id, f.color AS found_color, f.status AS found_status, f.image_path AS found_image
       FROM matches m
       JOIN items l ON l.id = m.lost_item_id
       JOIN items f ON f.id = m.found_item_id
       WHERE (l.user_id = ? OR f.user_id = ?) AND m.status != 'DISMISSED'
       ORDER BY m.similarity_score DESC`
    )
    .all(userId, userId)
    .map((m) => ({
      ...m,
      factors: JSON.parse(m.matching_factors || '{}')
    }));

  const myClaims = db
    .prepare(
      `SELECT c.*, f.item_name AS found_name, f.location AS found_location, f.category AS found_category,
              m.similarity_score
       FROM claims c
       JOIN items f ON f.id = c.found_item_id
       LEFT JOIN matches m ON m.id = c.match_id
       WHERE c.claimant_id = ?
       ORDER BY c.created_at DESC`
    )
    .all(userId);

  const recentNotifications = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5')
    .all(userId);

  const stats = {
    lostCount: myLostItems.length,
    foundCount: myFoundItems.length,
    matchCount: myMatches.length,
    claimCount: myClaims.length,
    returnedCount: db
      .prepare("SELECT COUNT(*) as c FROM claims WHERE claimant_id = ? AND status = 'COMPLETED'")
      .get(userId).c
  };

  res.render('dashboard', {
    pageTitle: 'Student Dashboard — FindBack AI',
    stats,
    myLostItems,
    myFoundItems,
    myMatches,
    myClaims,
    recentNotifications
  });
});

// Report Lost Item Form
router.get('/report-lost', requireAuth, (_req, res) => {
  res.render('report-lost', {
    pageTitle: 'Report Lost Item — FindBack AI',
    categories: VALID_CATEGORIES,
    today: new Date().toISOString().slice(0, 10)
  });
});

// Report Found Item Form
router.get('/report-found', requireAuth, (_req, res) => {
  res.render('report-found', {
    pageTitle: 'Report Found Item — FindBack AI',
    categories: VALID_CATEGORIES,
    today: new Date().toISOString().slice(0, 10)
  });
});

// AI Smart Matches Page
router.get('/matches', requireAuth, (req, res) => {
  const userId = req.currentUser.id;
  const scope = req.query.scope === 'all' || req.currentUser.role === 'ADMIN' ? 'all' : 'mine';
  const minScore = Number(req.query.minScore) || 0;

  let sql = `
    SELECT m.*,
           l.item_name AS lost_name, l.category AS lost_category, l.description AS lost_desc,
           l.color AS lost_color, l.brand AS lost_brand, l.location AS lost_location,
           l.event_date AS lost_date, l.image_path AS lost_image, l.user_id AS lost_user_id,
           lu.full_name AS lost_owner_name,
           f.item_name AS found_name, f.category AS found_category, f.description AS found_desc,
           f.color AS found_color, f.brand AS found_brand, f.location AS found_location,
           f.event_date AS found_date, f.image_path AS found_image, f.status AS found_status, f.user_id AS found_user_id,
           fu.full_name AS found_reporter_name,
           (SELECT c.id FROM claims c WHERE c.found_item_id = f.id AND c.claimant_id = ? AND c.status != 'REJECTED' LIMIT 1) AS my_existing_claim_id
    FROM matches m
    JOIN items l ON l.id = m.lost_item_id
    JOIN users lu ON lu.id = l.user_id
    JOIN items f ON f.id = m.found_item_id
    JOIN users fu ON fu.id = f.user_id
    WHERE m.status != 'DISMISSED'
  `;

  const params = [userId];

  if (scope === 'mine' && req.currentUser.role !== 'ADMIN') {
    sql += ' AND (l.user_id = ? OR f.user_id = ?)';
    params.push(userId, userId);
  }

  if (minScore > 0) {
    sql += ' AND m.similarity_score >= ?';
    params.push(minScore);
  }

  sql += ' ORDER BY m.similarity_score DESC, m.created_at DESC';

  const matches = db
    .prepare(sql)
    .all(...params)
    .map((m) => ({
      ...m,
      factors: JSON.parse(m.matching_factors || '{}')
    }));

  res.render('matches', {
    pageTitle: 'AI Smart Matches — FindBack AI',
    matches,
    scope,
    minScore
  });
});

// Claims Page
router.get('/claims', requireAuth, (req, res) => {
  const userId = req.currentUser.id;
  const preselectedFoundId = req.query.found_item_id ? Number(req.query.found_item_id) : null;
  const preselectedLostId = req.query.lost_item_id ? Number(req.query.lost_item_id) : null;
  const preselectedMatchId = req.query.match_id ? Number(req.query.match_id) : null;

  const availableFoundItems = db
    .prepare(
      `SELECT id, item_name, category, color, location, event_date, status
       FROM items
       WHERE type = 'FOUND' AND status NOT IN ('RETURNED', 'ARCHIVED')
       ORDER BY created_at DESC`
    )
    .all();

  const myLostItems = db
    .prepare(
      `SELECT id, item_name, category, location, event_date
       FROM items
       WHERE user_id = ? AND type = 'LOST' AND status != 'RETURNED' AND status != 'ARCHIVED'
       ORDER BY created_at DESC`
    )
    .all(userId);

  const myClaims = db
    .prepare(
      `SELECT c.*,
              f.item_name AS found_name, f.category AS found_category, f.location AS found_location,
              f.color AS found_color, f.event_date AS found_date, f.image_path AS found_image,
              m.similarity_score,
              rv.full_name AS reviewer_name
       FROM claims c
       JOIN items f ON f.id = c.found_item_id
       LEFT JOIN matches m ON m.id = c.match_id
       LEFT JOIN users rv ON rv.id = c.reviewed_by
       WHERE c.claimant_id = ?
       ORDER BY c.created_at DESC`
    )
    .all(userId);

  res.render('claims', {
    pageTitle: 'My Ownership Claims — FindBack AI',
    availableFoundItems,
    myLostItems,
    myClaims,
    preselected: {
      foundItemId: preselectedFoundId,
      lostItemId: preselectedLostId,
      matchId: preselectedMatchId
    }
  });
});

// Notifications Page
router.get('/notifications', requireAuth, (req, res) => {
  const notifications = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 60')
    .all(req.currentUser.id);

  res.render('notifications', {
    pageTitle: 'Notifications — FindBack AI',
    notifications
  });
});

// Profile Page
router.get('/profile', requireAuth, (req, res) => {
  const userId = req.currentUser.id;
  const summary = {
    reportsSubmitted: db.prepare('SELECT COUNT(*) as c FROM items WHERE user_id = ?').get(userId).c,
    claimsSubmitted: db.prepare('SELECT COUNT(*) as c FROM claims WHERE claimant_id = ?').get(userId).c,
    itemsRecovered: db
      .prepare("SELECT COUNT(*) as c FROM claims WHERE claimant_id = ? AND status = 'COMPLETED'")
      .get(userId).c
  };

  res.render('profile', {
    pageTitle: 'Account Profile — FindBack AI',
    summary
  });
});

// Admin Dashboard Console
router.get('/admin', requireAdmin, (req, res) => {
  const activeTab = req.query.tab || 'claims';

  const metrics = {
    totalStudents: db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'STUDENT'").get().c,
    lostReports: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'LOST' AND status != 'ARCHIVED'").get().c,
    foundReports: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'FOUND' AND status != 'ARCHIVED'").get().c,
    aiMatches: db.prepare("SELECT COUNT(*) as c FROM matches WHERE status != 'DISMISSED'").get().c,
    pendingClaims: db.prepare("SELECT COUNT(*) as c FROM claims WHERE status = 'PENDING'").get().c,
    returnedItems: db.prepare("SELECT COUNT(*) as c FROM items WHERE type = 'FOUND' AND status = 'RETURNED'").get().c
  };

  const allClaims = db
    .prepare(
      `SELECT c.*,
              u.full_name AS claimant_name, u.email AS claimant_email, u.student_id AS claimant_student_id, u.department AS claimant_dept, u.phone AS claimant_phone,
              f.item_name AS found_name, f.category AS found_category, f.color AS found_color, f.location AS found_location, f.description AS found_desc, f.additional_details AS found_extra, f.image_path AS found_image,
              l.item_name AS lost_name, l.description AS lost_desc,
              m.similarity_score,
              rv.full_name AS reviewer_name
       FROM claims c
       JOIN users u ON u.id = c.claimant_id
       JOIN items f ON f.id = c.found_item_id
       LEFT JOIN items l ON l.id = c.lost_item_id
       LEFT JOIN matches m ON m.id = c.match_id
       LEFT JOIN users rv ON rv.id = c.reviewed_by
       ORDER BY CASE c.status
         WHEN 'PENDING' THEN 1
         WHEN 'APPROVED' THEN 2
         WHEN 'COMPLETED' THEN 3
         ELSE 4
       END, c.created_at DESC`
    )
    .all();

  const allMatches = db
    .prepare(
      `SELECT m.*,
              l.item_name AS lost_name, l.location AS lost_location, l.color AS lost_color, l.category AS lost_category, lu.full_name AS lost_owner,
              f.item_name AS found_name, f.location AS found_location, f.color AS found_color, f.category AS found_category, fu.full_name AS found_reporter
       FROM matches m
       JOIN items l ON l.id = m.lost_item_id
       JOIN users lu ON lu.id = l.user_id
       JOIN items f ON f.id = m.found_item_id
       JOIN users fu ON fu.id = f.user_id
       WHERE m.status != 'DISMISSED'
       ORDER BY m.similarity_score DESC`
    )
    .all()
    .map((m) => ({
      ...m,
      factors: JSON.parse(m.matching_factors || '{}')
    }));

  const allItems = db
    .prepare(
      `SELECT i.*, u.full_name AS reporter_name, u.student_id AS reporter_sid
       FROM items i
       JOIN users u ON u.id = i.user_id
       ORDER BY i.created_at DESC`
    )
    .all();

  const allUsers = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.student_id, u.department, u.year, u.phone, u.role, u.is_active, u.created_at,
              (SELECT COUNT(*) FROM items i WHERE i.user_id = u.id) AS item_count,
              (SELECT COUNT(*) FROM claims c WHERE c.claimant_id = u.id) AS claim_count
       FROM users u
       ORDER BY u.role ASC, u.created_at DESC`
    )
    .all();

  const activityLogs = db
    .prepare(
      `SELECT a.*, u.full_name AS actor_name, u.role AS actor_role
       FROM activity_logs a
       LEFT JOIN users u ON u.id = a.user_id
       ORDER BY a.created_at DESC
       LIMIT 60`
    )
    .all();

  res.render('admin', {
    pageTitle: 'Admin Verification Console — FindBack AI',
    activeTab,
    metrics,
    allClaims,
    allMatches,
    allItems,
    allUsers,
    activityLogs
  });
});

// Interactive Live TF-IDF Similarity Sandbox Endpoint (JSON)
router.post('/api/match-sandbox', (req, res) => {
  try {
    const lostSample = {
      item_name: req.body.lost_name || 'Lost Item',
      category: req.body.lost_category || 'Wallets & IDs',
      description: req.body.lost_description || '',
      color: req.body.lost_color || '',
      brand: req.body.lost_brand || '',
      location: req.body.lost_location || '',
      event_date: req.body.lost_date || new Date().toISOString().slice(0, 10),
      additional_details: ''
    };
    const foundSample = {
      item_name: req.body.found_name || 'Found Item',
      category: req.body.found_category || 'Wallets & IDs',
      description: req.body.found_description || '',
      color: req.body.found_color || '',
      brand: req.body.found_brand || '',
      location: req.body.found_location || '',
      event_date: req.body.found_date || new Date().toISOString().slice(0, 10),
      additional_details: ''
    };

    const allItems = db.prepare('SELECT * FROM items').all();
    const corpusTokens = [
      ...allItems.map((i) => preprocessAndTokenize(`${i.item_name} ${i.description} ${i.location}`).tokens),
      preprocessAndTokenize(`${lostSample.item_name} ${lostSample.description} ${lostSample.location}`).tokens,
      preprocessAndTokenize(`${foundSample.item_name} ${foundSample.description} ${foundSample.location}`).tokens
    ];
    const idfMap = computeCorpusIdf(corpusTokens);
    const result = calculateItemSimilarity(lostSample, foundSample, idfMap, corpusTokens.length);
    return res.json({ ok: true, ...result });
  } catch (err) {
    return res.status(400).json({ ok: false, error: err.message });
  }
});

module.exports = router;
