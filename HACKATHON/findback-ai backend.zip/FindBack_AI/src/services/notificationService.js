const { db } = require('../db');

function createNotification({ userId, type, title, message, link = '/dashboard' }) {
  if (!userId) return null;
  const info = db
    .prepare(
      `INSERT INTO notifications (user_id, type, title, message, link, is_read)
       VALUES (?, ?, ?, ?, ?, 0)`
    )
    .run(userId, type, title, message, link);
  return info.lastInsertRowid;
}

function notifyAdmins({ type, title, message, link = '/admin' }) {
  const admins = db.prepare("SELECT id FROM users WHERE role = 'ADMIN' AND is_active = 1").all();
  const stmt = db.prepare(
    `INSERT INTO notifications (user_id, type, title, message, link, is_read)
     VALUES (?, ?, ?, ?, ?, 0)`
  );
  for (const admin of admins) {
    stmt.run(admin.id, type, title, message, link);
  }
}

function logActivity({ userId = null, action, entityType, entityId = null, details, ipAddress = '' }) {
  db.prepare(
    `INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, ip_address)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(userId, action, entityType, entityId, details, ipAddress || '');
}

function getUnreadCount(userId) {
  if (!userId) return 0;
  const row = db
    .prepare('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(userId);
  return row ? row.count : 0;
}

module.exports = {
  createNotification,
  notifyAdmins,
  logActivity,
  getUnreadCount
};
