const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { db } = require('../db');
const { getUnreadCount } = require('../services/notificationService');

const TOKEN_SECRET = process.env.SESSION_SECRET || 'findback-ai-campus-hackathon-secret-2026';

/**
 * Create a compact HMAC-signed session token so embedded preview environments
 * with strict third-party iframe cookie policies still maintain authenticated sessions seamlessly,
 * while localhost and normal browsers use standard Express session cookies automatically.
 */
function signUserToken(userId) {
  const payload = `${userId}.${Date.now()}`;
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('hex').slice(0, 24);
  return `${payload}.${sig}`;
}

function verifyUserToken(token) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [userIdStr, tsStr, sig] = parts;
  const payload = `${userIdStr}.${tsStr}`;
  const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('hex').slice(0, 24);
  if (sig !== expected) return null;
  const age = Date.now() - Number(tsStr);
  if (Number.isNaN(age) || age < 0 || age > 7 * 24 * 60 * 60 * 1000) return null;
  return Number(userIdStr);
}

/**
 * Attach current user, flash toast messages, unread notification count, and ZIP availability to res.locals
 */
function attachLocals(req, res, next) {
  let sessionUser = req.session && req.session.user ? req.session.user : null;

  // Fallback check if browser blocked third-party cookie in cross-origin preview iframe
  if (!sessionUser) {
    const fallbackToken =
      (req.query && req.query._ft) ||
      (req.body && req.body._ft) ||
      req.headers['x-findback-token'];
    const verifiedId = verifyUserToken(fallbackToken);
    if (verifiedId) {
      const freshUser = db
        .prepare(
          'SELECT id, full_name, email, student_id, department, year, phone, role, is_active FROM users WHERE id = ? AND is_active = 1'
        )
        .get(verifiedId);
      if (freshUser) {
        sessionUser = freshUser;
        if (req.session) {
          req.session.user = freshUser;
        }
      }
    }
  } else {
    // Refresh active user state from SQLite
    const freshUser = db
      .prepare(
        'SELECT id, full_name, email, student_id, department, year, phone, role, is_active FROM users WHERE id = ?'
      )
      .get(sessionUser.id);
    if (!freshUser || !freshUser.is_active) {
      if (req.session) delete req.session.user;
      sessionUser = null;
    } else {
      sessionUser = freshUser;
      req.session.user = freshUser;
    }
  }

  req.currentUser = sessionUser;
  res.locals.currentUser = sessionUser;
  res.locals.authToken = sessionUser ? signUserToken(sessionUser.id) : '';
  res.locals.unreadNotifications = sessionUser ? getUnreadCount(sessionUser.id) : 0;
  res.locals.currentPath = req.path;

  // Toast notifications via session or query params
  let toast = null;
  if (req.session && req.session.toast) {
    toast = req.session.toast;
    delete req.session.toast;
  } else if (req.query.msg) {
    toast = {
      type: req.query.type === 'error' ? 'error' : 'success',
      message: String(req.query.msg)
    };
  }
  res.locals.toast = toast;

  // Check if downloadable hackathon ZIP package exists in workspace root or project root
  const rootZip = path.resolve(__dirname, '../../../FindBack_AI_Hackathon.zip');
  const localZip = path.resolve(__dirname, '../../FindBack_AI_Hackathon.zip');
  res.locals.zipAvailable = fs.existsSync(rootZip) || fs.existsSync(localZip);

  next();
}

function setFlashRedirect(req, res, targetUrl, message, type = 'success') {
  if (req.session) {
    req.session.toast = { type, message };
  }
  const sep = targetUrl.includes('?') ? '&' : '?';
  const tokenParam = req.currentUser ? `&_ft=${encodeURIComponent(signUserToken(req.currentUser.id))}` : '';
  return res.redirect(
    `${targetUrl}${sep}msg=${encodeURIComponent(message)}&type=${encodeURIComponent(type)}${tokenParam}`
  );
}

function requireAuth(req, res, next) {
  if (!req.currentUser) {
    return setFlashRedirect(req, res, '/login', 'Please sign in to access your campus workspace.', 'error');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.currentUser) {
    return setFlashRedirect(req, res, '/login', 'Administrator login required.', 'error');
  }
  if (req.currentUser.role !== 'ADMIN') {
    return setFlashRedirect(req, res, '/dashboard', 'Access restricted to Campus Administrators.', 'error');
  }
  next();
}

module.exports = {
  attachLocals,
  requireAuth,
  requireAdmin,
  setFlashRedirect,
  signUserToken,
  verifyUserToken
};
