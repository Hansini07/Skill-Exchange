const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const bcrypt = require('bcrypt');
const session = require('express-session');
const { runFullDatabaseMatching } = require('./matcher');

const projectRoot = path.resolve(__dirname, '..');
const dataDir = path.join(projectRoot, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const resolvedDbPath = process.env.DB_PATH
  ? path.resolve(projectRoot, process.env.DB_PATH)
  : path.join(dataDir, 'findback.sqlite');

const db = new Database(resolvedDbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

/**
 * Custom lightweight SQLite Session Store for express-session
 * Ensures zero MemoryStore warnings and persists sessions across restarts.
 */
class SQLiteSessionStore extends session.Store {
  constructor(database) {
    super();
    this.db = database;
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS sessions (
        sid TEXT PRIMARY KEY,
        sess TEXT NOT NULL,
        expired INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_sessions_expired ON sessions(expired);
    `);

    this.getStmt = this.db.prepare('SELECT sess FROM sessions WHERE sid = ? AND expired > ?');
    this.setStmt = this.db.prepare(`
      INSERT INTO sessions (sid, sess, expired)
      VALUES (?, ?, ?)
      ON CONFLICT(sid) DO UPDATE SET sess = excluded.sess, expired = excluded.expired
    `);
    this.destroyStmt = this.db.prepare('DELETE FROM sessions WHERE sid = ?');
    this.pruneStmt = this.db.prepare('DELETE FROM sessions WHERE expired <= ?');
  }

  get(sid, cb) {
    try {
      const row = this.getStmt.get(sid, Date.now());
      if (!row) return cb(null, null);
      return cb(null, JSON.parse(row.sess));
    } catch (err) {
      return cb(err);
    }
  }

  set(sid, sess, cb) {
    try {
      const maxAge = sess.cookie && sess.cookie.maxAge ? sess.cookie.maxAge : 86400000 * 7;
      const expired = Date.now() + maxAge;
      this.setStmt.run(sid, JSON.stringify(sess), expired);
      if (Math.random() < 0.05) {
        this.pruneStmt.run(Date.now());
      }
      if (cb) cb(null);
    } catch (err) {
      if (cb) cb(err);
    }
  }

  destroy(sid, cb) {
    try {
      this.destroyStmt.run(sid);
      if (cb) cb(null);
    } catch (err) {
      if (cb) cb(err);
    }
  }
}

function computeItemFingerprint(userId, type, itemName, category, eventDate, location) {
  const raw = [
    String(userId),
    (type || '').toUpperCase().trim(),
    (itemName || '').toLowerCase().trim(),
    (category || '').toLowerCase().trim(),
    (eventDate || '').trim(),
    (location || '').toLowerCase().trim()
  ].join('|');
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 32);
}

function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      student_id TEXT UNIQUE,
      department TEXT NOT NULL,
      year TEXT NOT NULL,
      phone TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('STUDENT', 'ADMIN')) DEFAULT 'STUDENT',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('LOST', 'FOUND')),
      item_name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      color TEXT NOT NULL,
      brand TEXT DEFAULT '',
      event_date TEXT NOT NULL,
      location TEXT NOT NULL,
      additional_details TEXT DEFAULT '',
      image_path TEXT DEFAULT '',
      status TEXT NOT NULL CHECK(status IN ('OPEN', 'MATCHED', 'CLAIMED', 'RETURNED', 'ARCHIVED')) DEFAULT 'OPEN',
      fingerprint TEXT UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS matches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lost_item_id INTEGER NOT NULL,
      found_item_id INTEGER NOT NULL,
      similarity_score REAL NOT NULL,
      matching_factors TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('DETECTED', 'CLAIM_SUBMITTED', 'VERIFIED', 'DISMISSED', 'RETURNED')) DEFAULT 'DETECTED',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(lost_item_id, found_item_id),
      FOREIGN KEY (lost_item_id) REFERENCES items(id) ON DELETE CASCADE,
      FOREIGN KEY (found_item_id) REFERENCES items(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS claims (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      found_item_id INTEGER NOT NULL,
      lost_item_id INTEGER,
      match_id INTEGER,
      claimant_id INTEGER NOT NULL,
      ownership_explanation TEXT NOT NULL,
      identifying_details TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED')) DEFAULT 'PENDING',
      admin_notes TEXT DEFAULT '',
      reviewed_by INTEGER,
      reviewed_at TEXT,
      returned_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (found_item_id) REFERENCES items(id) ON DELETE CASCADE,
      FOREIGN KEY (lost_item_id) REFERENCES items(id) ON DELETE SET NULL,
      FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE SET NULL,
      FOREIGN KEY (claimant_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL CHECK(type IN (
        'REPORT_SUBMITTED',
        'MATCH_DISCOVERED',
        'CLAIM_SUBMITTED',
        'CLAIM_APPROVED',
        'CLAIM_REJECTED',
        'ITEM_RETURNED',
        'SYSTEM'
      )),
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      link TEXT DEFAULT '/dashboard',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id INTEGER,
      details TEXT NOT NULL,
      ip_address TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE INDEX IF NOT EXISTS idx_items_type_status ON items(type, status);
    CREATE INDEX IF NOT EXISTS idx_items_category ON items(category);
    CREATE INDEX IF NOT EXISTS idx_items_user_id ON items(user_id);
    CREATE INDEX IF NOT EXISTS idx_matches_score ON matches(similarity_score DESC);
    CREATE INDEX IF NOT EXISTS idx_matches_lost ON matches(lost_item_id);
    CREATE INDEX IF NOT EXISTS idx_matches_found ON matches(found_item_id);
    CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
    CREATE INDEX IF NOT EXISTS idx_claims_claimant ON claims(claimant_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read);
    CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_logs(created_at DESC);
  `);

  const existingUsers = db.prepare('SELECT COUNT(*) as count FROM users').get();
  if (existingUsers.count === 0) {
    seedDemoData();
  }
}

function seedDemoData() {
  const adminHash = bcrypt.hashSync('Admin@123', 10);
  const studentHash = bcrypt.hashSync('Student@123', 10);

  const insertUser = db.prepare(`
    INSERT INTO users (full_name, email, student_id, department, year, phone, password_hash, role)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertItem = db.prepare(`
    INSERT INTO items (
      user_id, type, item_name, category, description, color, brand,
      event_date, location, additional_details, image_path, status, fingerprint, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertNotification = db.prepare(`
    INSERT INTO notifications (user_id, type, title, message, link, is_read, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const insertLog = db.prepare(`
    INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, ip_address, created_at)
    VALUES (?, ?, ?, ?, ?, '127.0.0.1', ?)
  `);

  const seedTx = db.transaction(() => {
    // 1 Admin (id = 1)
    const adminRes = insertUser.run(
      'Dr. Elena Vance',
      'admin@findback.ai',
      'ADM-0001',
      'Campus Security & Student Affairs',
      'Staff',
      '+1 (555) 201-9000',
      adminHash,
      'ADMIN'
    );
    const adminId = adminRes.lastInsertRowid;

    // 10 Demo Students (ids 2..11)
    const studentsData = [
      ['Aarav Sharma', 'aarav.sharma@campus.edu', 'STU-2026-101', 'Computer Science', '3rd Year', '+1 (555) 310-1101'],
      ['Priya Patel', 'priya.patel@campus.edu', 'STU-2026-102', 'Electronics Engineering', '2nd Year', '+1 (555) 310-1102'],
      ['Rohan Verma', 'rohan.verma@campus.edu', 'STU-2026-103', 'Mechanical Engineering', '4th Year', '+1 (555) 310-1103'],
      ['Ananya Iyer', 'ananya.iyer@campus.edu', 'STU-2026-104', 'Biotechnology', '3rd Year', '+1 (555) 310-1104'],
      ['Vikram Nair', 'vikram.nair@campus.edu', 'STU-2026-105', 'Data Science & AI', '2nd Year', '+1 (555) 310-1105'],
      ['Neha Gupta', 'neha.gupta@campus.edu', 'STU-2026-106', 'Architecture', '1st Year', '+1 (555) 310-1106'],
      ['Kabir Mehta', 'kabir.mehta@campus.edu', 'STU-2026-107', 'Civil Engineering', '4th Year', '+1 (555) 310-1107'],
      ['Ishita Rao', 'ishita.rao@campus.edu', 'STU-2026-108', 'Economics', '2nd Year', '+1 (555) 310-1108'],
      ['Arjun Desai', 'arjun.desai@campus.edu', 'STU-2026-109', 'Robotics & Automation', '3rd Year', '+1 (555) 310-1109'],
      ['Meera Krishnan', 'meera.krishnan@campus.edu', 'STU-2026-110', 'Physics', '1st Year', '+1 (555) 310-1110']
    ];

    const studentIds = studentsData.map((s) => {
      const res = insertUser.run(s[0], s[1], s[2], s[3], s[4], s[5], studentHash, 'STUDENT');
      return res.lastInsertRowid;
    });

    // 15 LOST REPORTS
    const lostReports = [
      // #1 Primary Hackathon Demo Scenario (Student A: Aarav Sharma)
      {
        userId: studentIds[0],
        name: 'Black Leather Wallet with College ID',
        cat: 'Wallets & IDs',
        desc: 'Black wallet with college ID near library. Classic stitched leather bifold wallet slipped out of my backpack.',
        color: 'Black',
        brand: 'Fossil',
        date: '2026-10-28',
        loc: 'Central Library 2nd Floor Reading Room',
        extra: 'Contains blue student identity card (STU-2026-101), transit metro pass, and $25 cash.',
        img: '/images/black-wallet.jpg',
        createdAt: '2026-10-28 14:20:00'
      },
      // #2 Completed Demonstration Lifecycle (Student C: Rohan Verma)
      {
        userId: studentIds[2],
        name: 'Matte Navy Insulated Water Bottle',
        cat: 'Water Bottles & Gear',
        desc: 'Lost my matte navy blue stainless steel insulated flask with loop cap in the engineering lab.',
        color: 'Navy Blue',
        brand: 'HydroFlask',
        date: '2026-10-22',
        loc: 'Engineering Block Lab 204',
        extra: 'Small silver scratch near base and robotics club decal on bottom.',
        img: '/images/navy-bottle.jpg',
        createdAt: '2026-10-22 16:10:00'
      },
      // #3 Space Gray MacBook Pro
      {
        userId: studentIds[4],
        name: 'MacBook Pro 14-inch Space Gray',
        cat: 'Electronics',
        desc: 'Left my closed space gray aluminum MacBook Pro laptop on the wooden lecture desk after AI class.',
        color: 'Space Gray',
        brand: 'Apple',
        date: '2026-10-27',
        loc: 'Main Lecture Hall B',
        extra: 'Has a magnetic privacy screen filter installed; serial ends in K9Q2.',
        img: '/images/space-gray-laptop.jpg',
        createdAt: '2026-10-27 12:45:00'
      },
      // #4 White AirPods Pro Case
      {
        userId: studentIds[5],
        name: 'AirPods Pro Charging Case',
        cat: 'Electronics',
        desc: 'Dropped white wireless earbuds charging case on the concrete courtyard bench near the architecture studio.',
        color: 'White',
        brand: 'Apple',
        date: '2026-10-26',
        loc: 'Main Courtyard Bench near Architecture Wing',
        extra: 'Faint pencil mark on lid hinge; both earbuds were inside.',
        img: '/images/wireless-earbuds.jpg',
        createdAt: '2026-10-26 17:30:00'
      },
      // #5 Scientific Calculator
      {
        userId: studentIds[6],
        name: 'Casio FX-991EX ClassWiz Calculator',
        cat: 'Electronics',
        desc: 'Black and white scientific calculator left on exam desk after structural mechanics quiz.',
        color: 'Black',
        brand: 'Casio',
        date: '2026-10-25',
        loc: 'Science Block Room 108',
        extra: 'Initials KM written in silver marker on the slide cover.',
        img: '',
        createdAt: '2026-10-25 11:15:00'
      },
      // #6 Tortoiseshell Prescription Glasses
      {
        userId: studentIds[7],
        name: 'Tortoiseshell Eyeglasses in Hard Case',
        cat: 'Clothing & Eyewear',
        desc: 'Reading spectacles inside a brown vegan leather snap case left at the cafeteria coffee counter.',
        color: 'Brown',
        brand: 'Warby Parker',
        date: '2026-10-24',
        loc: 'Student Center Cafeteria',
        extra: 'Microfiber cloth inside is pale green.',
        img: '',
        createdAt: '2026-10-24 13:50:00'
      },
      // #7 Campus Dorm Keyring
      {
        userId: studentIds[8],
        name: 'Dorm Room Keys with Blue Lanyard',
        cat: 'ID Cards & Keys',
        desc: 'Set of three brass keys on a royal blue woven campus lanyard with a mini LED flashlight.',
        color: 'Royal Blue',
        brand: 'Generic',
        date: '2026-10-27',
        loc: 'North Gate Shuttle Stop',
        extra: 'Key tag stamped Room N-412.',
        img: '',
        createdAt: '2026-10-27 09:10:00'
      },
      // #8 USB-C Laptop Charger
      {
        userId: studentIds[1],
        name: '65W USB-C Power Adapter & Braided Cord',
        cat: 'Electronics',
        desc: 'Black compact GaN fast charger plugged into the floor socket under the group study table.',
        color: 'Black',
        brand: 'Anker',
        date: '2026-10-26',
        loc: 'Central Library Ground Floor Commons',
        extra: 'Velcro cable tie in neon yellow.',
        img: '',
        createdAt: '2026-10-26 19:00:00'
      },
      // #9 Architecture Sketchbook
      {
        userId: studentIds[5],
        name: 'Hardcover A4 Isometric Sketchbook',
        cat: 'Books & Stationery',
        desc: 'Black linen hardcover drafting notebook filled with urban studio ink elevation drawings.',
        color: 'Black',
        brand: 'Moleskine',
        date: '2026-10-23',
        loc: 'Design Studio 3rd Floor',
        extra: 'Name Neha G. written inside front cover.',
        img: '',
        createdAt: '2026-10-23 18:20:00'
      },
      // #10 Charcoal Fleece Hoodie
      {
        userId: studentIds[9],
        name: 'Charcoal Zip-Up Campus Hoodie',
        cat: 'Clothing & Eyewear',
        desc: 'Dark gray zip sweatshirt draped over bleachers during intramural basketball practice.',
        color: 'Charcoal Gray',
        brand: 'Nike',
        date: '2026-10-25',
        loc: 'Campus Sports Complex Gymnasium',
        extra: 'Size Medium, Physics Society patch on left sleeve.',
        img: '',
        createdAt: '2026-10-25 20:05:00'
      },
      // #11 Olive Canvas Backpack
      {
        userId: studentIds[3],
        name: 'Olive Green Daypack with Lab Coat',
        cat: 'Bags & Backpacks',
        desc: 'Compact olive canvas rucksack containing a folded white cotton biotechnology lab coat and goggles.',
        color: 'Olive Green',
        brand: 'Herschel',
        date: '2026-10-24',
        loc: 'Biotech Research Annex Lobby',
        extra: 'Enamel DNA helix pin on front pocket.',
        img: '',
        createdAt: '2026-10-24 15:40:00'
      },
      // #12 Apple Pencil 2nd Gen
      {
        userId: studentIds[0],
        name: 'Matte White Digital Stylus Pen',
        cat: 'Electronics',
        desc: 'Apple Pencil 2nd generation detached magnetically from iPad while walking between halls.',
        color: 'White',
        brand: 'Apple',
        date: '2026-10-29',
        loc: 'Walkway between CSE Block and Library',
        extra: 'Engraved with AS26 near flat edge.',
        img: '',
        createdAt: '2026-10-29 10:30:00'
      },
      // #13 Silver Analog Wristwatch
      {
        userId: studentIds[6],
        name: 'Brushed Steel Chronograph Watch',
        cat: 'Accessories',
        desc: 'Removed silver stainless steel watch before washing hands in washroom near auditorium.',
        color: 'Silver',
        brand: 'Seiko',
        date: '2026-10-21',
        loc: 'Main Auditorium Restroom Foyer',
        extra: 'Midnight blue dial with leather-backed link strap.',
        img: '',
        createdAt: '2026-10-21 16:45:00'
      },
      // #14 Badminton Racquet in Cover
      {
        userId: studentIds[8],
        name: 'Carbon Fiber Badminton Racquet',
        cat: 'Sports Equipment',
        desc: 'Black and red Yonex badminton racquet inside full-zip padded shoulder sleeve.',
        color: 'Red',
        brand: 'Yonex',
        date: '2026-10-20',
        loc: 'Indoor Sports Complex Court 3',
        extra: 'White overgrip newly wrapped on handle.',
        img: '',
        createdAt: '2026-10-20 19:30:00'
      },
      // #15 Portable SSD Drive
      {
        userId: studentIds[4],
        name: '1TB Rugged External SSD',
        cat: 'Electronics',
        desc: 'Small dark gray rubberized portable SSD with orange carabiner loop containing thesis datasets.',
        color: 'Gray',
        brand: 'SanDisk',
        date: '2026-10-28',
        loc: 'CSE Innovation Lab Terminal 12',
        extra: 'Short USB-C to USB-C cable attached.',
        img: '',
        createdAt: '2026-10-28 17:15:00'
      }
    ];

    const lostItemIds = lostReports.map((item) => {
      const fp = computeItemFingerprint(item.userId, 'LOST', item.name, item.cat, item.date, item.loc);
      const res = insertItem.run(
        item.userId,
        'LOST',
        item.name,
        item.cat,
        item.desc,
        item.color,
        item.brand,
        item.date,
        item.loc,
        item.extra,
        item.img,
        'OPEN',
        fp,
        item.createdAt
      );
      return res.lastInsertRowid;
    });

    // 15 FOUND REPORTS
    const foundReports = [
      // #1 Matches Lost #1 (Student B: Priya Patel finds Aarav's Black Wallet!)
      {
        userId: studentIds[1],
        name: 'Black Leather Bifold Wallet',
        cat: 'Wallets & IDs',
        desc: 'Black leather wallet with student identity card found close to central library study tables on 2nd floor.',
        color: 'Black',
        brand: 'Fossil',
        date: '2026-10-28',
        loc: 'Central Library 2nd Floor',
        extra: 'Turned in securely; has a blue university ID card visible in inner slot.',
        img: '/images/black-wallet.jpg',
        createdAt: '2026-10-28 16:05:00'
      },
      // #2 Matches Lost #2 (Ananya Iyer finds Rohan's Navy Bottle -> Completed Return Scenario)
      {
        userId: studentIds[3],
        name: 'Navy Blue Stainless Insulated Flask',
        cat: 'Water Bottles & Gear',
        desc: 'Found a matte navy blue insulated metal water bottle standing beside oscilloscope bench in engineering lab.',
        color: 'Navy',
        brand: 'HydroFlask',
        date: '2026-10-22',
        loc: 'Engineering Building Lab 204',
        extra: 'Has a small club sticker underneath.',
        img: '/images/navy-bottle.jpg',
        createdAt: '2026-10-22 18:00:00'
      },
      // #3 Matches Lost #3 (MacBook Pro)
      {
        userId: studentIds[7],
        name: 'Space Gray Apple MacBook Laptop',
        cat: 'Electronics',
        desc: 'Found a closed 14-inch space gray aluminum MacBook laptop on the third row wooden desk in Lecture Hall B.',
        color: 'Space Gray',
        brand: 'Apple',
        date: '2026-10-27',
        loc: 'Main Lecture Hall B',
        extra: 'Handed to department desk for safekeeping.',
        img: '/images/space-gray-laptop.jpg',
        createdAt: '2026-10-27 14:10:00'
      },
      // #4 Matches Lost #4 (AirPods Pro)
      {
        userId: studentIds[2],
        name: 'White Wireless Earbuds Case',
        cat: 'Electronics',
        desc: 'Picked up a white Apple AirPods Pro charging case sitting on a stone bench in the main courtyard.',
        color: 'Matte White',
        brand: 'Apple',
        date: '2026-10-26',
        loc: 'Main Courtyard near Architecture Building',
        extra: 'Green LED lights up when tapped.',
        img: '/images/wireless-earbuds.jpg',
        createdAt: '2026-10-26 18:15:00'
      },
      // #5 Matches Lost #5 (Casio Calculator)
      {
        userId: studentIds[9],
        name: 'Casio Scientific Calculator FX-991EX',
        cat: 'Electronics',
        desc: 'Found black Casio ClassWiz calculator left behind on front desk in Science Block.',
        color: 'Black',
        brand: 'Casio',
        date: '2026-10-25',
        loc: 'Science Block Classroom 108',
        extra: 'Has silver initials on protective hard cover.',
        img: '',
        createdAt: '2026-10-25 13:20:00'
      },
      // #6 Matches Lost #6 (Eyeglasses)
      {
        userId: studentIds[0],
        name: 'Brown Case with Prescription Glasses',
        cat: 'Clothing & Eyewear',
        desc: 'Found tortoiseshell frame spectacles inside a brown snap case near cafeteria espresso counter.',
        color: 'Brown',
        brand: 'Warby Parker',
        date: '2026-10-24',
        loc: 'Student Center Cafeteria Counter',
        extra: 'Kept safe at Student Union helpdesk.',
        img: '',
        createdAt: '2026-10-24 15:00:00'
      },
      // #7 Matches Lost #7 (Blue Lanyard Keys)
      {
        userId: studentIds[4],
        name: 'Keys on Royal Blue Campus Lanyard',
        cat: 'ID Cards & Keys',
        desc: 'Three brass room keys attached to a blue woven lanyard and mini keychain torch found at shuttle bench.',
        color: 'Blue',
        brand: 'Unknown',
        date: '2026-10-27',
        loc: 'North Gate Bus & Shuttle Stop',
        extra: 'Numbered dorm tag attached.',
        img: '',
        createdAt: '2026-10-27 10:05:00'
      },
      // #8 Matches Lost #8 (Anker 65W Charger)
      {
        userId: studentIds[8],
        name: 'Black USB-C Fast Charger Block',
        cat: 'Electronics',
        desc: 'Anker 65W USB-C wall adapter with braided cable and yellow strap found under library group study table.',
        color: 'Black',
        brand: 'Anker',
        date: '2026-10-27',
        loc: 'Central Library Ground Floor',
        extra: 'Plugged into floor outlet.',
        img: '',
        createdAt: '2026-10-27 08:45:00'
      },
      // #9 Matches Lost #15 (SanDisk SSD)
      {
        userId: studentIds[1],
        name: 'Rugged Gray SanDisk Portable SSD',
        cat: 'Electronics',
        desc: 'Found small dark gray rubberized SanDisk external SSD plugged into workstation in CSE Innovation Lab.',
        color: 'Gray',
        brand: 'SanDisk',
        date: '2026-10-28',
        loc: 'CSE Innovation Lab',
        extra: 'Orange corner loop and short USB-C cord.',
        img: '',
        createdAt: '2026-10-28 19:10:00'
      },
      // #10 Unmatched Found Item: Red Umbrella
      {
        userId: studentIds[3],
        name: 'Compact Crimson Folding Umbrella',
        cat: 'Accessories',
        desc: 'Automatic windproof red umbrella with wooden handle left in umbrella stand outside Chemistry auditorium.',
        color: 'Crimson Red',
        brand: 'Totes',
        date: '2026-10-26',
        loc: 'Chemistry Auditorium Entrance',
        extra: 'Matching red sleeve still on handle.',
        img: '',
        createdAt: '2026-10-26 16:30:00'
      },
      // #11 Unmatched Found Item: Graphing Textbook
      {
        userId: studentIds[5],
        name: 'Linear Algebra & Its Applications Textbook',
        cat: 'Books & Stationery',
        desc: 'Hardcover 6th edition Gilbert Strang Linear Algebra textbook found on quad lawn bench.',
        color: 'Blue',
        brand: 'Cengage',
        date: '2026-10-25',
        loc: 'Central Academic Quad',
        extra: 'Yellow sticky notes in Chapter 4.',
        img: '',
        createdAt: '2026-10-25 17:00:00'
      },
      // #12 Unmatched Found Item: Silver Ring
      {
        userId: studentIds[6],
        name: 'Minimalist Sterling Silver Band Ring',
        cat: 'Accessories',
        desc: 'Small hammered sterling silver ring found on sink counter in Fine Arts studio.',
        color: 'Silver',
        brand: 'Unbranded',
        date: '2026-10-23',
        loc: 'Fine Arts Building 1st Floor',
        extra: 'Engraved pattern inside band.',
        img: '',
        createdAt: '2026-10-23 14:15:00'
      },
      // #13 Unmatched Found Item: Wireless Mouse
      {
        userId: studentIds[7],
        name: 'Graphite Ergonomic Wireless Mouse',
        cat: 'Electronics',
        desc: 'Logitech MX Master ergonomic mouse left on coworking booth desk in Student Union.',
        color: 'Graphite',
        brand: 'Logitech',
        date: '2026-10-29',
        loc: 'Student Center 2nd Floor Quiet Zone',
        extra: 'Switched off to preserve battery.',
        img: '',
        createdAt: '2026-10-29 09:40:00'
      },
      // #14 Unmatched Found Item: Black Denim Jacket
      {
        userId: studentIds[9],
        name: 'Washed Black Oversized Denim Jacket',
        cat: 'Clothing & Eyewear',
        desc: 'Black cotton denim jacket found folded on back row seat after evening film screening.',
        color: 'Black',
        brand: 'Levi Strauss',
        date: '2026-10-27',
        loc: 'Media & Performing Arts Amphitheater',
        extra: 'Size Large; empty pockets.',
        img: '',
        createdAt: '2026-10-27 21:15:00'
      },
      // #15 Matches Lost #11 (Olive Backpack)
      {
        userId: studentIds[2],
        name: 'Olive Canvas Backpack with White Coat',
        cat: 'Bags & Backpacks',
        desc: 'Found an olive green Herschel backpack near the Biotech Research Annex elevator bench.',
        color: 'Olive Green',
        brand: 'Herschel',
        date: '2026-10-24',
        loc: 'Biotech Research Annex Ground Lobby',
        extra: 'Science pin on front zipper pocket.',
        img: '',
        createdAt: '2026-10-24 17:25:00'
      }
    ];

    const foundItemIds = foundReports.map((item) => {
      const fp = computeItemFingerprint(item.userId, 'FOUND', item.name, item.cat, item.date, item.loc);
      const res = insertItem.run(
        item.userId,
        'FOUND',
        item.name,
        item.cat,
        item.desc,
        item.color,
        item.brand,
        item.date,
        item.loc,
        item.extra,
        item.img,
        'OPEN',
        fp,
        item.createdAt
      );
      return res.lastInsertRowid;
    });

    // Execute REAL TF-IDF + Cosine Similarity matching across all 30 seeded items
    runFullDatabaseMatching(db);

    // Retrieve specific matches for realistic demo claims & lifecycle
    const findMatch = db.prepare(
      'SELECT id, similarity_score FROM matches WHERE lost_item_id = ? AND found_item_id = ?'
    );

    const insertClaim = db.prepare(`
      INSERT INTO claims (
        found_item_id, lost_item_id, match_id, claimant_id,
        ownership_explanation, identifying_details, status,
        admin_notes, reviewed_by, reviewed_at, returned_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // 1. Complete 7-Step Returned Lifecycle: Rohan Verma's Navy Insulated Bottle (Lost #2 <-> Found #2)
    const bottleMatch = findMatch.get(lostItemIds[1], foundItemIds[1]);
    if (bottleMatch) {
      const claimRes = insertClaim.run(
        foundItemIds[1],
        lostItemIds[1],
        bottleMatch.id,
        studentIds[2],
        'I left my 32oz navy HydroFlask beside the Tektronix oscilloscope in Lab 204 after Thursday embedded systems lab.',
        'Silver scratch along bottom rim and a circular Robotics Society 2025 vinyl sticker on the underside.',
        'COMPLETED',
        'Verified student ID STU-2026-103 and confirmed underside Robotics decal in person at Security Desk.',
        adminId,
        '2026-10-23 10:15:00',
        '2026-10-23 14:30:00',
        '2026-10-22 19:20:00'
      );
      db.prepare("UPDATE items SET status = 'RETURNED' WHERE id IN (?, ?)").run(
        lostItemIds[1],
        foundItemIds[1]
      );
      db.prepare("UPDATE matches SET status = 'RETURNED' WHERE id = ?").run(bottleMatch.id);

      insertNotification.run(
        studentIds[2],
        'ITEM_RETURNED',
        'Item Returned Successfully',
        'Your Matte Navy Insulated Water Bottle handover has been completed and logged by Campus Admin.',
        '/claims',
        0,
        '2026-10-23 14:30:00'
      );
      insertLog.run(
        adminId,
        'ITEM_RETURNED',
        'CLAIM',
        claimRes.lastInsertRowid,
        'Marked claim #' + claimRes.lastInsertRowid + ' (Navy Insulated Bottle) as RETURNED to Rohan Verma.',
        '2026-10-23 14:30:00'
      );
    }

    // 2. PENDING Claim waiting for Admin Verification: Vikram Nair's Space Gray MacBook Pro (Lost #3 <-> Found #3)
    const laptopMatch = findMatch.get(lostItemIds[2], foundItemIds[2]);
    if (laptopMatch) {
      const claimRes = insertClaim.run(
        foundItemIds[2],
        lostItemIds[2],
        laptopMatch.id,
        studentIds[4],
        'I accidentally left my 14-inch Space Gray MacBook Pro on row 3 of Lecture Hall B right after CS-302.',
        'Serial number ends in K9Q2, magnetic Kensington privacy screen attached, login user displays Vikram N.',
        'PENDING',
        '',
        null,
        null,
        null,
        '2026-10-27 15:30:00'
      );
      db.prepare("UPDATE items SET status = 'CLAIMED' WHERE id = ?").run(foundItemIds[2]);
      db.prepare("UPDATE matches SET status = 'CLAIM_SUBMITTED' WHERE id = ?").run(laptopMatch.id);

      insertNotification.run(
        adminId,
        'CLAIM_SUBMITTED',
        'New Ownership Claim Pending Verification',
        'Vikram Nair submitted a claim for Space Gray Apple MacBook Laptop (' + laptopMatch.similarity_score + '% AI match).',
        '/admin?tab=claims',
        0,
        '2026-10-27 15:30:00'
      );
      insertLog.run(
        studentIds[4],
        'CLAIM_SUBMITTED',
        'CLAIM',
        claimRes.lastInsertRowid,
        'Submitted ownership claim for Space Gray Apple MacBook Laptop.',
        '2026-10-27 15:30:00'
      );
    }

    // 3. APPROVED Claim awaiting pickup: Neha Gupta's AirPods Pro Case (Lost #4 <-> Found #4)
    const earbudsMatch = findMatch.get(lostItemIds[3], foundItemIds[3]);
    if (earbudsMatch) {
      const claimRes = insertClaim.run(
        foundItemIds[3],
        lostItemIds[3],
        earbudsMatch.id,
        studentIds[5],
        'Dropped my AirPods Pro case on the courtyard bench outside the Architecture Wing on Monday afternoon.',
        'Pairs automatically with my iPhone ("Neha’s AirPods Pro") and has a tiny graphite mark near the back hinge.',
        'APPROVED',
        'Bluetooth pairing name and hinge mark verified. Ready for student pickup at Room 102.',
        adminId,
        '2026-10-27 11:00:00',
        null,
        '2026-10-26 20:10:00'
      );
      db.prepare("UPDATE items SET status = 'CLAIMED' WHERE id = ?").run(foundItemIds[3]);
      db.prepare("UPDATE matches SET status = 'VERIFIED' WHERE id = ?").run(earbudsMatch.id);

      insertNotification.run(
        studentIds[5],
        'CLAIM_APPROVED',
        'Ownership Claim Approved',
        'Admin verified your claim for White Wireless Earbuds Case. Please visit Campus Lost & Found Desk with your ID.',
        '/claims',
        0,
        '2026-10-27 11:00:00'
      );
      insertLog.run(
        adminId,
        'CLAIM_APPROVED',
        'CLAIM',
        claimRes.lastInsertRowid,
        'Approved claim #' + claimRes.lastInsertRowid + ' for Neha Gupta (White Wireless Earbuds Case).',
        '2026-10-27 11:00:00'
      );
    }

    // 4. REJECTED Claim sample (insufficient proof from wrong claimant)
    insertClaim.run(
      foundItemIds[4],
      null,
      null,
      studentIds[8],
      'I lost a scientific calculator last month somewhere in the main building.',
      'It is a standard black calculator, no markings on the cover.',
      'REJECTED',
      'Identifying details did not match: found item has specific silver initials on the slide cover.',
      adminId,
      '2026-10-26 09:45:00',
      null,
      '2026-10-25 18:00:00'
    );

    // 5. Primary Wallet Demo Match Notification for Student A (Aarav Sharma) & Student B (Priya Patel)
    // Kept UNCLAIMED in 'DETECTED' state so Student A can click "Claim Item" live during demo!
    const walletMatch = findMatch.get(lostItemIds[0], foundItemIds[0]);
    if (walletMatch) {
      insertNotification.run(
        studentIds[0],
        'REPORT_SUBMITTED',
        'Lost Item Report Logged',
        'Your report for "Black Leather Wallet with College ID" is active and indexed by FindBack AI.',
        '/dashboard',
        1,
        '2026-10-28 14:20:05'
      );
      insertNotification.run(
        studentIds[0],
        'MATCH_DISCOVERED',
        'High-Confidence AI Match Discovered (' + walletMatch.similarity_score + '%)',
        'Our TF-IDF matching engine found a strong match ("Black Leather Bifold Wallet" at Central Library 2nd Floor). Review & submit a claim.',
        '/matches',
        0,
        '2026-10-28 16:05:10'
      );
      insertNotification.run(
        studentIds[1],
        'MATCH_DISCOVERED',
        'Potential Owner Matched (' + walletMatch.similarity_score + '%)',
        'The Black Leather Bifold Wallet you reported matched a lost item report near Central Library.',
        '/matches',
        0,
        '2026-10-28 16:05:10'
      );
      insertLog.run(
        studentIds[0],
        'REPORT_LOST',
        'ITEM',
        lostItemIds[0],
        'Reported lost item: Black Leather Wallet with College ID (Central Library 2nd Floor Reading Room).',
        '2026-10-28 14:20:00'
      );
      insertLog.run(
        studentIds[1],
        'REPORT_FOUND',
        'ITEM',
        foundItemIds[0],
        'Reported found item: Black Leather Bifold Wallet -> Triggered ' + walletMatch.similarity_score + '% AI match.',
        '2026-10-28 16:05:00'
      );
    }
  });

  seedTx();
}

// Automatically ensure schema, indexes, and initial demo seed are initialized on first load
initializeDatabase();

module.exports = {
  db,
  SQLiteSessionStore,
  initializeDatabase,
  computeItemFingerprint
};
