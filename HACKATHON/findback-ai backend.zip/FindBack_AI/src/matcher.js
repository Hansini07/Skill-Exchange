/**
 * FindBack AI - Local Smart Item Matching Engine
 * Uses Text Preprocessing, Stopword Removal, Stemming/Synonym Canonicalization,
 * Corpus-Wide TF-IDF Vectorization, Cosine Similarity, and Multi-Attribute Scoring.
 * Zero external APIs or hardcoded percentages.
 */

const STOPWORDS = new Set([
  'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'else', 'when',
  'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into',
  'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from',
  'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again',
  'further', 'once', 'here', 'there', 'where', 'why', 'how', 'all', 'any',
  'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no',
  'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
  'can', 'will', 'just', 'should', 'now', 'is', 'was', 'were', 'be',
  'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'my', 'your',
  'his', 'her', 'its', 'our', 'their', 'this', 'that', 'these', 'those',
  'i', 'me', 'we', 'us', 'you', 'he', 'him', 'she', 'they', 'them',
  'lost', 'found', 'missing', 'left', 'dropped', 'picked', 'someone',
  'near', 'close', 'around', 'inside', 'outside', 'beside', 'next',
  'item', 'belonging', 'thing', 'please', 'contact', 'return', 'today',
  'yesterday', 'morning', 'afternoon', 'evening', 'while', 'studying'
]);

const SYNONYM_MAP = {
  id: ['identity', 'card'],
  idcard: ['identity', 'card'],
  identity: ['identity', 'card'],
  college: ['campus', 'student'],
  university: ['campus', 'student'],
  uni: ['campus', 'student'],
  student: ['campus', 'student'],
  lib: ['library'],
  library: ['library'],
  airpods: ['earbuds', 'wireless', 'apple'],
  airpod: ['earbuds', 'wireless', 'apple'],
  earphones: ['earbuds', 'audio'],
  earbuds: ['earbuds', 'audio'],
  headphones: ['headphones', 'audio'],
  macbook: ['laptop', 'apple', 'macbook'],
  notebook: ['notebook', 'laptop'],
  laptop: ['laptop', 'computer'],
  specs: ['glasses', 'eyewear'],
  spectacles: ['glasses', 'eyewear'],
  eyeglasses: ['glasses', 'eyewear'],
  sunglasses: ['glasses', 'eyewear'],
  bifold: ['wallet', 'leather'],
  purse: ['wallet', 'pouch'],
  tumbler: ['bottle', 'flask'],
  flask: ['bottle', 'flask'],
  hydroflask: ['bottle', 'flask', 'insulated'],
  thermos: ['bottle', 'flask', 'insulated'],
  charger: ['charger', 'adapter', 'power'],
  adapter: ['charger', 'adapter', 'power'],
  cord: ['cable', 'charger'],
  usb: ['cable', 'usb'],
  typec: ['usbc', 'cable'],
  'usbc': ['usbc', 'cable'],
  grey: ['gray'],
  gray: ['gray'],
  navy: ['navy', 'blue'],
  crimson: ['red'],
  maroon: ['red'],
  burgundy: ['red'],
  ivory: ['white'],
  cream: ['white'],
  charcoal: ['black', 'gray'],
  jet: ['black'],
  matte: ['matte'],
  cafeteria: ['canteen', 'dining', 'cafeteria'],
  canteen: ['canteen', 'dining', 'cafeteria'],
  mess: ['canteen', 'dining'],
  gym: ['sports', 'gymnasium'],
  gymnasium: ['sports', 'gymnasium'],
  auditorium: ['hall', 'auditorium'],
  cse: ['engineering', 'computer'],
  ece: ['engineering', 'electronics']
};

const COLOR_FAMILIES = {
  black: ['black', 'matte black', 'charcoal', 'jet black', 'dark gray', 'obsidian'],
  gray: ['gray', 'grey', 'silver', 'space gray', 'space grey', 'slate', 'graphite', 'metallic', 'charcoal'],
  white: ['white', 'pearl', 'ivory', 'cream', 'off-white', 'matte white', 'chalk'],
  blue: ['blue', 'navy', 'navy blue', 'royal blue', 'dark blue', 'sky blue', 'cobalt', 'indigo', 'teal'],
  red: ['red', 'crimson', 'maroon', 'burgundy', 'scarlet', 'rose', 'wine'],
  green: ['green', 'olive', 'forest green', 'sage', 'mint', 'emerald'],
  brown: ['brown', 'tan', 'leather', 'camel', 'cognac', 'espresso', 'beige', 'khaki'],
  yellow: ['yellow', 'gold', 'mustard', 'amber'],
  purple: ['purple', 'violet', 'lavender', 'plum'],
  pink: ['pink', 'rose gold', 'blush', 'coral'],
  orange: ['orange', 'rust', 'copper']
};

const RELATED_CATEGORIES = {
  'Wallets & IDs': ['ID Cards & Keys', 'Accessories', 'Bags & Backpacks'],
  'ID Cards & Keys': ['Wallets & IDs', 'Accessories'],
  'Electronics': ['Accessories'],
  'Accessories': ['Electronics', 'Wallets & IDs', 'Clothing & Eyewear', 'Bags & Backpacks'],
  'Bags & Backpacks': ['Accessories', 'Books & Stationery'],
  'Books & Stationery': ['Bags & Backpacks'],
  'Water Bottles & Gear': ['Sports Equipment', 'Accessories'],
  'Sports Equipment': ['Water Bottles & Gear', 'Clothing & Eyewear'],
  'Clothing & Eyewear': ['Accessories', 'Sports Equipment']
};

const CAMPUS_ZONES = {
  library_zone: ['library', 'central library', 'reading room', 'study hall', 'archives', 'learning commons'],
  engineering_zone: ['engineering', 'cse', 'ece', 'mechanical', 'robotics', 'computer lab', 'innovation lab', 'lab', 'tech block'],
  dining_zone: ['cafeteria', 'canteen', 'student center', 'food court', 'coffee', 'dining hall', 'quad'],
  sports_zone: ['gym', 'gymnasium', 'sports complex', 'basketball', 'stadium', 'track', 'locker room', 'court'],
  lecture_zone: ['lecture hall', 'auditorium', 'main block', 'science block', 'seminar hall', 'amphitheater'],
  hostel_zone: ['hostel', 'dorm', 'residence', 'north gate', 'south gate', 'shuttle stop', 'parking']
};

/**
 * Lightweight suffix stemmer for English nouns/adjectives
 */
function stemWord(word) {
  if (word.length <= 3) return word;
  if (word.endsWith('ies') && word.length > 4) return word.slice(0, -3) + 'y';
  if (word.endsWith('ves') && word.length > 4) return word.slice(0, -3) + 'f';
  if (word.endsWith('ing') && word.length > 5) return word.slice(0, -3);
  if (word.endsWith('ed') && word.length > 4) return word.slice(0, -2);
  if (word.endsWith('es') && word.length > 4 && !word.endsWith('ses') && !word.endsWith('ches')) {
    // e.g. watches -> watch, boxes -> box, glasses -> glass
    if (word.endsWith('ches') || word.endsWith('shes') || word.endsWith('xes')) {
      return word.slice(0, -2);
    }
  }
  if (word.endsWith('ches') || word.endsWith('shes') || word.endsWith('xes')) {
    return word.slice(0, -2);
  }
  if (word.endsWith('s') && !word.endsWith('ss') && !word.endsWith('us') && word.length > 3) {
    return word.slice(0, -1);
  }
  return word;
}

/**
 * Preprocess text: lowercase, strip symbols, tokenize, remove stopwords, stem, and expand synonyms
 */
function preprocessAndTokenize(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    return { tokens: [], rawKeywords: [] };
  }

  const cleaned = rawText
    .toLowerCase()
    .replace(/usb-c|type-c/g, 'usbc')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleaned) return { tokens: [], rawKeywords: [] };

  const words = cleaned.split(' ');
  const tokens = [];
  const rawKeywords = [];

  for (const w of words) {
    if (w.length < 2 || STOPWORDS.has(w)) continue;
    rawKeywords.push(w);

    const stemmed = stemWord(w);
    if (!STOPWORDS.has(stemmed)) {
      tokens.push(stemmed);
    }

    if (SYNONYM_MAP[w]) {
      for (const syn of SYNONYM_MAP[w]) {
        tokens.push(stemWord(syn));
      }
    } else if (SYNONYM_MAP[stemmed]) {
      for (const syn of SYNONYM_MAP[stemmed]) {
        tokens.push(stemWord(syn));
      }
    }
  }

  return { tokens, rawKeywords };
}

/**
 * Build combined text representation of an item report for TF-IDF analysis
 */
function buildItemDocument(item) {
  // Weight item_name and core description slightly higher by natural repetition
  return [
    item.item_name || '',
    item.item_name || '',
    item.category || '',
    item.description || '',
    item.additional_details || '',
    item.color || '',
    item.brand || '',
    item.location || ''
  ].join(' ');
}

/**
 * Compute Smoothed IDF map across a corpus of token arrays
 * IDF(t) = ln((1 + N) / (1 + df(t))) + 1
 */
function computeCorpusIdf(corpusTokenLists) {
  const N = Math.max(corpusTokenLists.length, 1);
  const docFreq = new Map();

  for (const tokenList of corpusTokenLists) {
    const uniqueInDoc = new Set(tokenList);
    for (const token of uniqueInDoc) {
      docFreq.set(token, (docFreq.get(token) || 0) + 1);
    }
  }

  const idfMap = new Map();
  for (const [token, df] of docFreq.entries()) {
    idfMap.set(token, Math.log((1 + N) / (1 + df)) + 1);
  }
  return idfMap;
}

/**
 * Compute TF-IDF vector for a single document's tokens using sublinear TF
 */
function computeTfIdfVector(tokens, idfMap, totalCorpusDocs = 10) {
  const counts = new Map();
  for (const t of tokens) {
    counts.set(t, (counts.get(t) || 0) + 1);
  }

  const vector = new Map();
  const fallbackIdf = Math.log(1 + totalCorpusDocs) + 1;

  for (const [token, count] of counts.entries()) {
    // Sublinear TF: 1 + ln(count)
    const tf = 1 + Math.log(count);
    const idf = idfMap.get(token) || fallbackIdf;
    vector.set(token, tf * idf);
  }
  return vector;
}

/**
 * Mathematical Cosine Similarity between two sparse Map vectors
 */
function cosineSimilarity(vecA, vecB) {
  if (vecA.size === 0 || vecB.size === 0) return 0;

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (const [token, weightA] of vecA.entries()) {
    normA += weightA * weightA;
    if (vecB.has(token)) {
      dotProduct += weightA * vecB.get(token);
    }
  }

  for (const weightB of vecB.values()) {
    normB += weightB * weightB;
  }

  const denominator = Math.sqrt(normA) * Math.sqrt(normB);
  if (denominator === 0) return 0;
  return Math.min(1, Math.max(0, dotProduct / denominator));
}

/**
 * Compare Category similarity (0 to 1)
 */
function compareCategory(catA, catB) {
  if (!catA || !catB) return 0.3;
  const a = catA.trim();
  const b = catB.trim();
  if (a.toLowerCase() === b.toLowerCase()) return 1.0;
  const related = RELATED_CATEGORIES[a] || [];
  if (related.some((r) => r.toLowerCase() === b.toLowerCase())) {
    return 0.48;
  }
  return 0.0;
}

/**
 * Compare Color similarity (0 to 1)
 */
function compareColor(colorA, colorB) {
  const a = (colorA || '').toLowerCase().trim();
  const b = (colorB || '').toLowerCase().trim();
  if (!a || !b || a === 'unknown' || b === 'unknown' || a === 'n/a' || b === 'n/a') {
    return 0.45;
  }
  if (a === b) return 1.0;
  if (a.includes(b) || b.includes(a)) return 0.9;

  for (const variants of Object.values(COLOR_FAMILIES)) {
    const aIn = variants.some((v) => a.includes(v) || v.includes(a));
    const bIn = variants.some((v) => b.includes(v) || v.includes(b));
    if (aIn && bIn) return 0.82;
  }
  return 0.0;
}

/**
 * Levenshtein edit distance for fuzzy brand matching
 */
function levenshtein(s1, s2) {
  const m = s1.length;
  const n = s2.length;
  const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

/**
 * Compare Brand similarity (0 to 1)
 */
function compareBrand(brandA, brandB) {
  const clean = (val) =>
    (val || '')
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '')
      .trim();

  const a = clean(brandA);
  const b = clean(brandB);

  const unspecified = new Set(['', 'none', 'unknown', 'na', 'unbranded', 'generic', 'notapplicable']);
  if (unspecified.has(a) && unspecified.has(b)) return 0.65;
  if (unspecified.has(a) || unspecified.has(b)) return 0.58;

  if (a === b) return 1.0;
  if (a.includes(b) || b.includes(a)) return 0.88;

  const maxLen = Math.max(a.length, b.length);
  if (maxLen > 3) {
    const dist = levenshtein(a, b);
    const ratio = 1 - dist / maxLen;
    if (ratio >= 0.7) return ratio;
  }
  return 0.05;
}

/**
 * Compare Campus Location similarity (0 to 1)
 */
function compareLocation(locA, locB) {
  const a = (locA || '').toLowerCase().trim();
  const b = (locB || '').toLowerCase().trim();
  if (!a || !b) return 0.35;
  if (a === b) return 1.0;
  if (a.includes(b) || b.includes(a)) return 0.92;

  const tokensA = preprocessAndTokenize(a).tokens;
  const tokensB = preprocessAndTokenize(b).tokens;
  const setB = new Set(tokensB);
  const overlap = tokensA.filter((t) => setB.has(t));

  if (overlap.length > 0) {
    const unionSize = new Set([...tokensA, ...tokensB]).size;
    return Math.min(0.95, 0.6 + (overlap.length / Math.max(1, unionSize)) * 0.4);
  }

  for (const places of Object.values(CAMPUS_ZONES)) {
    const aZone = places.some((p) => a.includes(p));
    const bZone = places.some((p) => b.includes(p));
    if (aZone && bZone) return 0.72;
  }

  return 0.12;
}

/**
 * Compare Date proximity between Lost Date and Found Date (0 to 1)
 */
function compareDates(lostDateStr, foundDateStr) {
  if (!lostDateStr || !foundDateStr) return 0.5;
  const lostTime = new Date(lostDateStr).getTime();
  const foundTime = new Date(foundDateStr).getTime();
  if (Number.isNaN(lostTime) || Number.isNaN(foundTime)) return 0.5;

  // diffDays > 0 means found AFTER lost (normal logical sequence)
  const diffDays = (foundTime - lostTime) / (1000 * 60 * 60 * 24);

  if (Math.abs(diffDays) <= 0.5) return 1.0; // Same day
  if (diffDays > 0 && diffDays <= 2) return 0.94;
  if (diffDays > 2 && diffDays <= 5) return 0.82;
  if (diffDays > 5 && diffDays <= 10) return 0.68;
  if (diffDays > 10 && diffDays <= 21) return 0.48;
  if (diffDays > 21) return 0.25;

  // Found slightly before reported lost date (student noticed 1-2 days late)
  if (diffDays < 0 && diffDays >= -2) return 0.76;
  if (diffDays < -2 && diffDays >= -5) return 0.42;
  return 0.1; // Found long before item was lost
}

/**
 * Calculate comprehensive similarity score (0 - 100) between a LOST item and a FOUND item
 */
function calculateItemSimilarity(lostItem, foundItem, idfMap, corpusSize = 20) {
  const lostDoc = preprocessAndTokenize(buildItemDocument(lostItem));
  const foundDoc = preprocessAndTokenize(buildItemDocument(foundItem));

  const vecLost = computeTfIdfVector(lostDoc.tokens, idfMap, corpusSize);
  const vecFound = computeTfIdfVector(foundDoc.tokens, idfMap, corpusSize);

  const rawCosine = cosineSimilarity(vecLost, vecFound);

  // Token overlap coefficient (Szymkiewicz-Simpson) helps concise human descriptions
  const setLost = new Set(lostDoc.tokens);
  const setFound = new Set(foundDoc.tokens);
  const sharedTokens = [...setLost].filter((t) => setFound.has(t));
  const minSetSize = Math.min(setLost.size, setFound.size);
  const overlapCoeff = minSetSize > 0 ? sharedTokens.length / minSetSize : 0;

  // Blended NLP semantic score (70% TF-IDF Cosine + 30% Token Overlap)
  const textScore = Math.min(1, rawCosine * 0.7 + overlapCoeff * 0.3);

  const categoryScore = compareCategory(lostItem.category, foundItem.category);
  const colorScore = compareColor(lostItem.color, foundItem.color);
  const brandScore = compareBrand(lostItem.brand, foundItem.brand);
  const locationScore = compareLocation(lostItem.location, foundItem.location);
  const dateScore = compareDates(lostItem.event_date, foundItem.event_date);

  // Weighted Multi-Attribute Formula (Sums to 100)
  // Text TF-IDF + Overlap: 36%, Category: 20%, Color: 13%, Location: 13%, Brand: 9%, Date Proximity: 9%
  let weightedTotal =
    textScore * 36 +
    categoryScore * 20 +
    colorScore * 13 +
    locationScore * 13 +
    brandScore * 9 +
    dateScore * 9;

  // Apply category mismatch dampening so completely unrelated categories cannot score misleadingly high
  if (categoryScore === 0) {
    weightedTotal *= 0.58;
  }

  // Apply conflicting color dampening when both colors are explicitly different
  if (colorScore === 0) {
    weightedTotal *= 0.78;
  }

  const finalScore = Math.round(Math.min(99.4, Math.max(0, weightedTotal)) * 10) / 10;

  // Human-readable shared keywords (clean unique words)
  const displayKeywords = [...new Set(sharedTokens)].slice(0, 8);

  const factors = {
    tfidfCosine: Math.round(rawCosine * 1000) / 10,
    textSimilarity: Math.round(textScore * 1000) / 10,
    categoryMatch: Math.round(categoryScore * 100),
    colorMatch: Math.round(colorScore * 100),
    locationProximity: Math.round(locationScore * 100),
    brandMatch: Math.round(brandScore * 100),
    dateProximity: Math.round(dateScore * 100),
    sharedKeywords: displayKeywords,
    confidenceTier:
      finalScore >= 75 ? 'HIGH' : finalScore >= 56 ? 'MODERATE' : 'POTENTIAL'
  };

  return {
    score: finalScore,
    factors
  };
}

/**
 * Run matching engine for a newly added/updated item against all active opposite-type items in SQLite,
 * or run full corpus matching.
 */
function runSmartMatchingForNewItem(db, targetItem, notifyCallback) {
  const allItems = db
    .prepare("SELECT * FROM items WHERE status NOT IN ('RETURNED', 'ARCHIVED')")
    .all();

  if (allItems.length === 0) return [];

  const corpusTokenLists = allItems.map((it) => preprocessAndTokenize(buildItemDocument(it)).tokens);
  const idfMap = computeCorpusIdf(corpusTokenLists);

  const oppositeType = targetItem.type === 'LOST' ? 'FOUND' : 'LOST';
  const candidates = allItems.filter(
    (it) => it.type === oppositeType && it.id !== targetItem.id
  );

  const upsertMatch = db.prepare(`
    INSERT INTO matches (lost_item_id, found_item_id, similarity_score, matching_factors, status)
    VALUES (?, ?, ?, ?, 'DETECTED')
    ON CONFLICT(lost_item_id, found_item_id) DO UPDATE SET
      similarity_score = excluded.similarity_score,
      matching_factors = excluded.matching_factors
  `);

  const updateItemStatus = db.prepare(`
    UPDATE items SET status = 'MATCHED' WHERE id = ? AND status = 'OPEN'
  `);

  const checkExistingMatch = db.prepare(`
    SELECT id, similarity_score FROM matches WHERE lost_item_id = ? AND found_item_id = ?
  `);

  const discoveredMatches = [];
  const MATCH_THRESHOLD = 44.0;
  const NOTIFY_THRESHOLD = 55.0;

  for (const candidate of candidates) {
    const lostItem = targetItem.type === 'LOST' ? targetItem : candidate;
    const foundItem = targetItem.type === 'FOUND' ? targetItem : candidate;

    const { score, factors } = calculateItemSimilarity(
      lostItem,
      foundItem,
      idfMap,
      allItems.length
    );

    if (score >= MATCH_THRESHOLD) {
      const existing = checkExistingMatch.get(lostItem.id, foundItem.id);
      upsertMatch.run(lostItem.id, foundItem.id, score, JSON.stringify(factors));

      if (score >= NOTIFY_THRESHOLD) {
        updateItemStatus.run(lostItem.id);
        updateItemStatus.run(foundItem.id);

        if (!existing && typeof notifyCallback === 'function') {
          notifyCallback({
            lostItem,
            foundItem,
            score,
            factors
          });
        }
      }

      discoveredMatches.push({
        lostItem,
        foundItem,
        score,
        factors
      });
    }
  }

  return discoveredMatches.sort((a, b) => b.score - a.score);
}

/**
 * Recompute matches across the entire active database (used during initial seed or admin re-index)
 */
function runFullDatabaseMatching(db) {
  const allItems = db
    .prepare("SELECT * FROM items WHERE status NOT IN ('RETURNED', 'ARCHIVED')")
    .all();

  const corpusTokenLists = allItems.map((it) => preprocessAndTokenize(buildItemDocument(it)).tokens);
  const idfMap = computeCorpusIdf(corpusTokenLists);

  const lostItems = allItems.filter((it) => it.type === 'LOST');
  const foundItems = allItems.filter((it) => it.type === 'FOUND');

  const upsertMatch = db.prepare(`
    INSERT INTO matches (lost_item_id, found_item_id, similarity_score, matching_factors, status)
    VALUES (?, ?, ?, ?, 'DETECTED')
    ON CONFLICT(lost_item_id, found_item_id) DO UPDATE SET
      similarity_score = excluded.similarity_score,
      matching_factors = excluded.matching_factors
  `);

  const updateItemStatus = db.prepare(`
    UPDATE items SET status = 'MATCHED' WHERE id = ? AND status = 'OPEN'
  `);

  let totalMatched = 0;

  const tx = db.transaction(() => {
    for (const lostItem of lostItems) {
      for (const foundItem of foundItems) {
        const { score, factors } = calculateItemSimilarity(
          lostItem,
          foundItem,
          idfMap,
          allItems.length
        );
        if (score >= 44.0) {
          upsertMatch.run(lostItem.id, foundItem.id, score, JSON.stringify(factors));
          if (score >= 55.0) {
            updateItemStatus.run(lostItem.id);
            updateItemStatus.run(foundItem.id);
          }
          totalMatched++;
        }
      }
    }
  });

  tx();
  return totalMatched;
}

module.exports = {
  preprocessAndTokenize,
  computeCorpusIdf,
  computeTfIdfVector,
  cosineSimilarity,
  calculateItemSimilarity,
  runSmartMatchingForNewItem,
  runFullDatabaseMatching
};
