const { db, computeItemFingerprint } = require('../db');
const { runSmartMatchingForNewItem } = require('../matcher');
const { setFlashRedirect } = require('../middleware/auth');
const { createNotification, logActivity } = require('../services/notificationService');

const VALID_CATEGORIES = new Set([
  'Wallets & IDs',
  'Electronics',
  'ID Cards & Keys',
  'Bags & Backpacks',
  'Water Bottles & Gear',
  'Books & Stationery',
  'Clothing & Eyewear',
  'Accessories',
  'Sports Equipment'
]);

function submitItemReport(type) {
  return (req, res) => {
    const formRoute = type === 'LOST' ? '/report-lost' : '/report-found';
    try {
      const userId = req.currentUser.id;
      const itemName = (req.body.item_name || '').trim();
      const category = (req.body.category || '').trim();
      const description = (req.body.description || '').trim();
      const color = (req.body.color || '').trim();
      const brand = (req.body.brand || '').trim();
      const eventDate = (req.body.event_date || '').trim();
      const location = (req.body.location || '').trim();
      const additionalDetails = (req.body.additional_details || '').trim();

      if (!itemName || !category || !description || !color || !eventDate || !location) {
        return setFlashRedirect(
          req,
          res,
          formRoute,
          'Please fill in all required item details (name, category, description, color, date, and location).',
          'error'
        );
      }

      if (!VALID_CATEGORIES.has(category)) {
        return setFlashRedirect(req, res, formRoute, 'Please select a valid item category.', 'error');
      }

      if (description.length < 10) {
        return setFlashRedirect(
          req,
          res,
          formRoute,
          'Please provide a descriptive summary (at least 10 characters) so the AI matcher can analyze key features.',
          'error'
        );
      }

      const fingerprint = computeItemFingerprint(userId, type, itemName, category, eventDate, location);
      const duplicate = db.prepare('SELECT id FROM items WHERE fingerprint = ?').get(fingerprint);
      if (duplicate) {
        return setFlashRedirect(
          req,
          res,
          formRoute,
          'Duplicate report prevented: you have already submitted an identical item report for this date and location.',
          'error'
        );
      }

      const imagePath = req.file ? `/uploads/${req.file.filename}` : '';

      const insertRes = db
        .prepare(
          `INSERT INTO items (
            user_id, type, item_name, category, description, color, brand,
            event_date, location, additional_details, image_path, status, fingerprint
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?)`
        )
        .run(
          userId,
          type,
          itemName,
          category,
          description,
          color,
          brand,
          eventDate,
          location,
          additionalDetails,
          imagePath,
          fingerprint
        );

      const newItemId = Number(insertRes.lastInsertRowid);
      const newItem = db.prepare('SELECT * FROM items WHERE id = ?').get(newItemId);

      // 1. Notify reporter that report is logged
      createNotification({
        userId,
        type: 'REPORT_SUBMITTED',
        title: `${type === 'LOST' ? 'Lost' : 'Found'} Item Report Submitted`,
        message: `"${itemName}" at ${location} has been saved and scanned by FindBack AI.`,
        link: '/dashboard'
      });

      logActivity({
        userId,
        action: type === 'LOST' ? 'REPORT_LOST' : 'REPORT_FOUND',
        entityType: 'ITEM',
        entityId: newItemId,
        details: `Submitted ${type} report: "${itemName}" (${category}, ${color}) at ${location}.`,
        ipAddress: req.ip
      });

      // 2. Run real TF-IDF + Cosine Similarity + Multi-Attribute Smart Matching automatically
      const matchesFound = runSmartMatchingForNewItem(db, newItem, ({ lostItem, foundItem, score }) => {
        // Notify Lost Item Owner
        createNotification({
          userId: lostItem.user_id,
          type: 'MATCH_DISCOVERED',
          title: `AI Smart Match Discovered (${score}%)`,
          message: `Potential match found between "${lostItem.item_name}" and "${foundItem.item_name}" (${foundItem.location}).`,
          link: '/matches'
        });

        // Notify Found Item Finder (if distinct user)
        if (foundItem.user_id !== lostItem.user_id) {
          createNotification({
            userId: foundItem.user_id,
            type: 'MATCH_DISCOVERED',
            title: `AI Smart Match Discovered (${score}%)`,
            message: `Your found report "${foundItem.item_name}" matched a lost item report ("${lostItem.item_name}").`,
            link: '/matches'
          });
        }
      });

      const highConfidenceCount = matchesFound.filter((m) => m.score >= 55).length;
      if (highConfidenceCount > 0) {
        const topScore = matchesFound[0].score;
        return setFlashRedirect(
          req,
          res,
          '/matches',
          `Report saved! FindBack AI detected ${matchesFound.length} potential match(es) — top similarity ${topScore}%.`,
          'success'
        );
      }

      return setFlashRedirect(
        req,
        res,
        '/dashboard',
        `${type === 'LOST' ? 'Lost' : 'Found'} item report saved! We will notify you automatically if a match appears.`,
        'success'
      );
    } catch (err) {
      console.error('Submit item error:', err);
      return setFlashRedirect(req, res, formRoute, 'Failed to submit item report. Please try again.', 'error');
    }
  };
}

function archiveOwnItem(req, res) {
  try {
    const itemId = Number(req.params.id);
    const item = db.prepare('SELECT * FROM items WHERE id = ?').get(itemId);
    if (!item) {
      return setFlashRedirect(req, res, '/dashboard', 'Item report not found.', 'error');
    }
    if (item.user_id !== req.currentUser.id && req.currentUser.role !== 'ADMIN') {
      return setFlashRedirect(req, res, '/dashboard', 'You can only manage your own item reports.', 'error');
    }
    if (item.status === 'RETURNED') {
      return setFlashRedirect(req, res, '/dashboard', 'Returned items are permanently archived in history.', 'error');
    }

    db.prepare("UPDATE items SET status = 'ARCHIVED' WHERE id = ?").run(itemId);
    logActivity({
      userId: req.currentUser.id,
      action: 'ITEM_ARCHIVED',
      entityType: 'ITEM',
      entityId: itemId,
      details: `Archived ${item.type} report #${itemId} ("${item.item_name}").`,
      ipAddress: req.ip
    });

    const redirectBack = req.currentUser.role === 'ADMIN' ? '/admin?tab=reports' : '/dashboard';
    return setFlashRedirect(req, res, redirectBack, `Report "${item.item_name}" archived.`, 'success');
  } catch (err) {
    console.error('Archive item error:', err);
    return setFlashRedirect(req, res, '/dashboard', 'Unable to archive item.', 'error');
  }
}

module.exports = {
  submitLostItem: submitItemReport('LOST'),
  submitFoundItem: submitItemReport('FOUND'),
  archiveOwnItem,
  VALID_CATEGORIES: [...VALID_CATEGORIES]
};
