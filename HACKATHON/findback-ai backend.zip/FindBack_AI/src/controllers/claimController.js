const { db } = require('../db');
const { setFlashRedirect } = require('../middleware/auth');
const { createNotification, notifyAdmins, logActivity } = require('../services/notificationService');

function submitClaim(req, res) {
  try {
    const claimantId = req.currentUser.id;
    const foundItemId = Number(req.body.found_item_id);
    const lostItemId = req.body.lost_item_id ? Number(req.body.lost_item_id) : null;
    const matchId = req.body.match_id ? Number(req.body.match_id) : null;
    const ownershipExplanation = (req.body.ownership_explanation || '').trim();
    const identifyingDetails = (req.body.identifying_details || '').trim();

    if (!foundItemId || !ownershipExplanation || !identifyingDetails) {
      return setFlashRedirect(
        req,
        res,
        '/claims',
        'Item ID, ownership explanation, and specific identifying details are required.',
        'error'
      );
    }

    if (ownershipExplanation.length < 12 || identifyingDetails.length < 8) {
      return setFlashRedirect(
        req,
        res,
        '/claims',
        'Please provide thorough ownership proof and specific hidden/identifying details for Admin verification.',
        'error'
      );
    }

    const foundItem = db.prepare('SELECT * FROM items WHERE id = ? AND type = ?').get(foundItemId, 'FOUND');
    if (!foundItem) {
      return setFlashRedirect(req, res, '/browse-items', 'Selected found item does not exist.', 'error');
    }

    if (foundItem.status === 'RETURNED') {
      return setFlashRedirect(req, res, '/browse-items', 'This item has already been verified and returned.', 'error');
    }

    // Prevent duplicate active claim by same student for the same found item
    const existingClaim = db
      .prepare(
        "SELECT id FROM claims WHERE found_item_id = ? AND claimant_id = ? AND status IN ('PENDING', 'APPROVED', 'COMPLETED')"
      )
      .get(foundItemId, claimantId);

    if (existingClaim) {
      return setFlashRedirect(
        req,
        res,
        '/claims',
        'You already have an active or approved claim for this found item.',
        'error'
      );
    }

    // Automatically link highest match if student has a matched lost item and matchId wasn't passed
    let resolvedMatchId = matchId;
    let resolvedLostItemId = lostItemId;
    if (!resolvedMatchId) {
      const autoMatch = db
        .prepare(
          `SELECT m.id, m.lost_item_id
           FROM matches m
           JOIN items l ON l.id = m.lost_item_id
           WHERE m.found_item_id = ? AND l.user_id = ?
           ORDER BY m.similarity_score DESC LIMIT 1`
        )
        .get(foundItemId, claimantId);

      if (autoMatch) {
        resolvedMatchId = autoMatch.id;
        resolvedLostItemId = resolvedLostItemId || autoMatch.lost_item_id;
      }
    }

    const insertRes = db
      .prepare(
        `INSERT INTO claims (
          found_item_id, lost_item_id, match_id, claimant_id,
          ownership_explanation, identifying_details, status
        ) VALUES (?, ?, ?, ?, ?, ?, 'PENDING')`
      )
      .run(
        foundItemId,
        resolvedLostItemId,
        resolvedMatchId,
        claimantId,
        ownershipExplanation,
        identifyingDetails
      );

    const claimId = Number(insertRes.lastInsertRowid);

    db.prepare("UPDATE items SET status = 'CLAIMED' WHERE id = ? AND status IN ('OPEN', 'MATCHED')").run(
      foundItemId
    );

    if (resolvedMatchId) {
      db.prepare("UPDATE matches SET status = 'CLAIM_SUBMITTED' WHERE id = ? AND status = 'DETECTED'").run(
        resolvedMatchId
      );
    }

    // Notify Student Claimant
    createNotification({
      userId: claimantId,
      type: 'CLAIM_SUBMITTED',
      title: 'Ownership Claim Submitted',
      message: `Your claim #CLM-${1000 + claimId} for "${foundItem.item_name}" is now pending Campus Admin verification.`,
      link: '/claims'
    });

    // Notify Admins
    notifyAdmins({
      type: 'CLAIM_SUBMITTED',
      title: 'New Ownership Claim Requires Verification',
      message: `${req.currentUser.full_name} submitted claim #CLM-${1000 + claimId} for "${foundItem.item_name}".`,
      link: '/admin?tab=claims'
    });

    logActivity({
      userId: claimantId,
      action: 'CLAIM_SUBMITTED',
      entityType: 'CLAIM',
      entityId: claimId,
      details: `${req.currentUser.full_name} submitted claim #CLM-${1000 + claimId} for found item #${foundItemId} ("${foundItem.item_name}").`,
      ipAddress: req.ip
    });

    return setFlashRedirect(
      req,
      res,
      '/claims',
      `Claim #CLM-${1000 + claimId} submitted! A Campus Administrator will review your proof details.`,
      'success'
    );
  } catch (err) {
    console.error('Submit claim error:', err);
    return setFlashRedirect(req, res, '/claims', 'Failed to submit ownership claim.', 'error');
  }
}

function markNotificationRead(req, res) {
  const notifId = Number(req.params.id);
  db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(
    notifId,
    req.currentUser.id
  );
  return setFlashRedirect(req, res, '/notifications', 'Notification marked as read.', 'success');
}

function markAllNotificationsRead(req, res) {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.currentUser.id);
  return setFlashRedirect(req, res, '/notifications', 'All notifications marked as read.', 'success');
}

module.exports = {
  submitClaim,
  markNotificationRead,
  markAllNotificationsRead
};
