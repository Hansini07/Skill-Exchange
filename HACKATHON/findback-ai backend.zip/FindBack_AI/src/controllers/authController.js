const bcrypt = require('bcrypt');
const { db } = require('../db');
const { setFlashRedirect } = require('../middleware/auth');
const { createNotification, logActivity } = require('../services/notificationService');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function registerStudent(req, res) {
  try {
    const fullName = (req.body.full_name || '').trim();
    const email = (req.body.email || '').toLowerCase().trim();
    const studentId = (req.body.student_id || '').toUpperCase().trim();
    const department = (req.body.department || '').trim();
    const year = (req.body.year || '').trim();
    const phone = (req.body.phone || '').trim();
    const password = req.body.password || '';

    if (!fullName || !email || !studentId || !department || !year || !phone || !password) {
      return setFlashRedirect(req, res, '/register', 'All registration fields are required.', 'error');
    }

    if (!EMAIL_REGEX.test(email)) {
      return setFlashRedirect(req, res, '/register', 'Please enter a valid college email address.', 'error');
    }

    if (password.length < 6) {
      return setFlashRedirect(req, res, '/register', 'Password must be at least 6 characters long.', 'error');
    }

    const existingEmail = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existingEmail) {
      return setFlashRedirect(req, res, '/register', 'An account with this college email already exists.', 'error');
    }

    const existingStuId = db.prepare('SELECT id FROM users WHERE student_id = ?').get(studentId);
    if (existingStuId) {
      return setFlashRedirect(req, res, '/register', 'This Student ID is already registered.', 'error');
    }

    const passwordHash = bcrypt.hashSync(password, 10);

    const insertResult = db
      .prepare(
        `INSERT INTO users (full_name, email, student_id, department, year, phone, password_hash, role)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'STUDENT')`
      )
      .run(fullName, email, studentId, department, year, phone, passwordHash);

    const newUserId = Number(insertResult.lastInsertRowid);
    const userRow = db
      .prepare(
        'SELECT id, full_name, email, student_id, department, year, phone, role, is_active FROM users WHERE id = ?'
      )
      .get(newUserId);

    req.session.user = userRow;
    req.currentUser = userRow;

    createNotification({
      userId: newUserId,
      type: 'SYSTEM',
      title: 'Welcome to FindBack AI',
      message: 'Your student account is verified. You can now report lost or found items and receive instant AI match alerts.',
      link: '/dashboard'
    });

    logActivity({
      userId: newUserId,
      action: 'STUDENT_REGISTER',
      entityType: 'USER',
      entityId: newUserId,
      details: `New student registered: ${fullName} (${studentId}, ${department})`,
      ipAddress: req.ip
    });

    return setFlashRedirect(req, res, '/dashboard', `Welcome aboard, ${fullName}! Your account is ready.`, 'success');
  } catch (err) {
    console.error('Registration error:', err);
    return setFlashRedirect(req, res, '/register', 'Unable to complete registration. Please check your details.', 'error');
  }
}

function loginUser(req, res) {
  try {
    const email = (req.body.email || '').toLowerCase().trim();
    const password = req.body.password || '';
    const loginPortal = (req.body.portal || '').toUpperCase();

    if (!email || !password) {
      return setFlashRedirect(req, res, '/login', 'Please provide both email and password.', 'error');
    }

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) {
      return setFlashRedirect(req, res, '/login', 'Invalid email or password.', 'error');
    }

    if (!user.is_active) {
      return setFlashRedirect(req, res, '/login', 'This account has been deactivated by Campus Administration.', 'error');
    }

    const validPassword = bcrypt.compareSync(password, user.password_hash);
    if (!validPassword) {
      return setFlashRedirect(req, res, '/login', 'Invalid email or password.', 'error');
    }

    if (loginPortal === 'ADMIN' && user.role !== 'ADMIN') {
      return setFlashRedirect(req, res, '/login?role=admin', 'Administrator privileges required for Admin portal.', 'error');
    }

    const safeUser = {
      id: user.id,
      full_name: user.full_name,
      email: user.email,
      student_id: user.student_id,
      department: user.department,
      year: user.year,
      phone: user.phone,
      role: user.role,
      is_active: user.is_active
    };

    req.session.user = safeUser;
    req.currentUser = safeUser;

    logActivity({
      userId: user.id,
      action: user.role === 'ADMIN' ? 'ADMIN_LOGIN' : 'STUDENT_LOGIN',
      entityType: 'USER',
      entityId: user.id,
      details: `${user.full_name} (${user.role}) signed in.`,
      ipAddress: req.ip
    });

    const destination = user.role === 'ADMIN' ? '/admin' : '/dashboard';
    return setFlashRedirect(req, res, destination, `Signed in as ${user.full_name}.`, 'success');
  } catch (err) {
    console.error('Login error:', err);
    return setFlashRedirect(req, res, '/login', 'Sign-in failed due to an unexpected error.', 'error');
  }
}

function logoutUser(req, res) {
  const user = req.currentUser;
  if (user) {
    logActivity({
      userId: user.id,
      action: 'LOGOUT',
      entityType: 'USER',
      entityId: user.id,
      details: `${user.full_name} signed out.`,
      ipAddress: req.ip
    });
  }

  req.currentUser = null;
  if (req.session) {
    req.session.destroy(() => {
      res.clearCookie('findback.sid');
      return res.redirect('/login?msg=' + encodeURIComponent('You have been securely logged out.') + '&type=success');
    });
  } else {
    return res.redirect('/login');
  }
}

function updateProfile(req, res) {
  try {
    const userId = req.currentUser.id;
    const fullName = (req.body.full_name || '').trim();
    const department = (req.body.department || '').trim();
    const year = (req.body.year || '').trim();
    const phone = (req.body.phone || '').trim();
    const currentPassword = req.body.current_password || '';
    const newPassword = req.body.new_password || '';

    if (!fullName || !department || !year || !phone) {
      return setFlashRedirect(req, res, '/profile', 'Full name, department, year, and phone cannot be empty.', 'error');
    }

    db.prepare(
      'UPDATE users SET full_name = ?, department = ?, year = ?, phone = ? WHERE id = ?'
    ).run(fullName, department, year, phone, userId);

    if (newPassword) {
      if (newPassword.length < 6) {
        return setFlashRedirect(req, res, '/profile', 'New password must be at least 6 characters.', 'error');
      }
      const userRecord = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(userId);
      if (!currentPassword || !bcrypt.compareSync(currentPassword, userRecord.password_hash)) {
        return setFlashRedirect(req, res, '/profile', 'Current password did not match. Password was not changed.', 'error');
      }
      const updatedHash = bcrypt.hashSync(newPassword, 10);
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(updatedHash, userId);
    }

    const updatedUser = db
      .prepare('SELECT id, full_name, email, student_id, department, year, phone, role, is_active FROM users WHERE id = ?')
      .get(userId);

    req.session.user = updatedUser;
    req.currentUser = updatedUser;

    logActivity({
      userId,
      action: 'PROFILE_UPDATED',
      entityType: 'USER',
      entityId: userId,
      details: `${fullName} updated account profile details.`,
      ipAddress: req.ip
    });

    return setFlashRedirect(req, res, '/profile', 'Profile settings saved successfully.', 'success');
  } catch (err) {
    console.error('Update profile error:', err);
    return setFlashRedirect(req, res, '/profile', 'Could not update profile settings.', 'error');
  }
}

module.exports = {
  registerStudent,
  loginUser,
  logoutUser,
  updateProfile
};
