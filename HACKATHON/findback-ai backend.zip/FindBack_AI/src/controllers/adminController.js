const { db } = require('../db');
const { runFullDatabaseMatching } = require('../matcher');
const { setFlashRedirect } = require('../middleware/auth');
const { createNotification, logActivity } = require('../services/notificationService');

function reviewClaim(req, res) {
  try {
    const claimId = Number(req.params.id);
    const decision = (req.body.decision || '').toUpperCase().trim();
    const adminNotes = (req.body.admin_notes || '').trim();
    const adminId = req.currentUser.id;

    if (!['APPROVED', 'REJECTED'].includes(decision)) {
      return setFlashRedirect(req, res, '/admin?tab=claims', 'Invalid verification action.', 'error');
    }

    const claim = db
      .prepare(
        `SELECT c.*, f.item_name AS found_name, f.user_id AS finder_id
         FROM claims c
         JOIN items f ON f.id = c.found_item_id
         WHERE c.id = ?`
      )
      .get(claimId);

    if (!claim) {
      return setFlashRedirect(req, res, '/admin?tab=claims', 'Claim record not found.', 'error');
    }

    if (claim.status === 'COMPLETED') {
      return setFlashRedirect(req, res, '/admin?tab=claims', 'Completed claims cannot be altered.', 'error');
    }

    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE claims
         SET status = ?, admin_notes = ?, reviewed_by = ?, reviewed_at = datetime('now')
         WHERE id = ?`
      ).run(decision, adminNotes || (decision === 'APPROVED' ? 'Ownership details verified by Admin.' : 'Insufficient identifying proof.'), adminId, claimId);

      if (decision === 'APPROVED') {
        db.prepare("UPDATE items SET status = 'CLAIMED' WHERE id = ?").run(claim.found_item_id);
        if (claim.match_id) {
          db.prepare("UPDATE matches SET status = 'VERIFIED' WHERE id = ?").run(claim.match_id);
        }

        // Reject other competing pending claims for the exact same found item
        const competing = db
          .prepare("SELECT id, claimant_id FROM claims WHERE found_item_id = ? AND id != ? AND status = 'PENDING'")
          .all(claim.found_item_id, claimId);

        for (const comp of competing) {
          db.prepare(
            "UPDATE claims SET status = 'REJECTED', admin_notes = 'Another verified owner claim was approved.', reviewed_by = ?, reviewed_at = datetime('now') WHERE id = ?"
          ).run(adminId, comp.id);

          createNotification({
            userId: comp.claimant_id,
            type: 'CLAIM_REJECTED',
            title: 'Ownership Claim Update',
            message: `Your claim #CLM-${1000 + comp.id} for "${claim.found_name}" was closed after another claimant provided verified ownership proof.`,
            link: '/claims'
          });
        }

        createNotification({
          userId: claim.claimant_id,
          type: 'CLAIM_APPROVED',
          title: 'Ownership Claim Approved!',
          message: `Your claim #CLM-${1000 + claimId} for "${claim.found_name}" has been verified by Admin. Please bring your Student ID to Campus Security Desk for pickup.`,
          link: '/claims'
        });
      } else {
        // REJECTED: reopen item if no other approved/pending claims exist
        const activeOthers = db
          .prepare(
            "SELECT COUNT(*) as cnt FROM claims WHERE found_item_id = ? AND id != ? AND status IN ('PENDING', 'APPROVED', 'COMPLETED')"
          )
          .get(claim.found_item_id, claimId);

        if (!activeOthers || activeOthers.cnt === 0) {
          const hasMatch = db
            .prepare('SELECT COUNT(*) as cnt FROM matches WHERE found_item_id = ? AND similarity_score >= 55')
            .get(claim.found_item_id);
          db.prepare('UPDATE items SET status = ? WHERE id = ?').run(
            hasMatch && hasMatch.cnt > 0 ? 'MATCHED' : 'OPEN',
            claim.found_item_id
          );
        }

        createNotification({
          userId: claim.claimant_id,
          type: 'CLAIM_REJECTED',
          title: 'Ownership Claim Not Approved',
          message: `Your claim #CLM-${1000 + claimId} for "${claim.found_name}" was rejected. Reason: ${adminNotes || 'Identifying details did not match.'}`,
          link: '/claims'
        });
      }

      logActivity({
        userId: adminId,
        action: decision === 'APPROVED' ? 'CLAIM_APPROVED' : 'CLAIM_REJECTED',
        entityType: 'CLAIM',
        entityId: claimId,
        details: `Admin ${decision.toLowerCase()} claim #CLM-${1000 + claimId} ("${claim.found_name}"). Notes: ${adminNotes || 'Standard verification'}`,
        ipAddress: req.ip
      });
    });

    tx();

    return setFlashRedirect(
      req,
      res,
      '/admin?tab=claims',
      `Claim #CLM-${1000 + claimId} has been ${decision.toLowerCase()}. Student notified.`,
      'success'
    );
  } catch (err) {
    console.error('Review claim error:', err);
    return setFlashRedirect(req, res, '/admin?tab=claims', 'Error processing claim decision.', 'error');
  }
}

function markClaimReturned(req, res) {
  try {
    const claimId = Number(req.params.id);
    const adminId = req.currentUser.id;
    const handoverNotes = (req.body.admin_notes || '').trim();

    const claim = db
      .prepare(
        `SELECT c.*, f.item_name AS found_name, f.user_id AS finder_id
         FROM claims c
         JOIN items f ON f.id = c.found_item_id
         WHERE c.id = ?`
      )
      .get(claimId);

    if (!claim) {
      return setFlashRedirect(req, res, '/admin?tab=claims', 'Claim not found.', 'error');
    }

    if (claim.status !== 'APPROVED') {
      return setFlashRedirect(
        req,
        res,
        '/admin?tab=claims',
        'Only APPROVED claims can be marked as returned to owner.',
        'error'
      );
    }

    const tx = db.transaction(() => {
      const updatedNotes = handoverNotes
        ? `${claim.admin_notes ? claim.admin_notes + ' | ' : ''}Handover: ${handoverNotes}`
        : claim.admin_notes;

      db.prepare(
        `UPDATE claims
         SET status = 'COMPLETED', admin_notes = ?, returned_at = datetime('now')
         WHERE id = ?`
      ).run(updatedNotes, claimId);

      db.prepare("UPDATE items SET status = 'RETURNED' WHERE id = ?").run(claim.found_item_id);
      if (claim.lost_item_id) {
        db.prepare("UPDATE items SET status = 'RETURNED' WHERE id = ?").run(claim.lost_item_id);
      }
      if (claim.match_id) {
        db.prepare("UPDATE matches SET status = 'RETURNED' WHERE id = ?").run(claim.match_id);
      }

      // Notify rightful owner
      createNotification({
        userId: claim.claimant_id,
        type: 'ITEM_RETURNED',
        title: 'Item Returned & Case Closed',
        message: `Your "${claim.found_name}" (#CLM-${1000 + claimId}) has been officially marked as returned. Glad you have it back!`,
        link: '/claims'
      });

      // Thank the student who found it
      if (claim.finder_id && claim.finder_id !== claim.claimant_id) {
        createNotification({
          userId: claim.finder_id,
          type: 'ITEM_RETURNED',
          title: 'Thank You! Found Item Returned to Owner',
          message: `The "${claim.found_name}" you turned in has been verified and returned to its rightful owner.`,
          link: '/dashboard'
        });
      }

      logActivity({
        userId: adminId,
        action: 'ITEM_RETURNED',
        entityType: 'CLAIM',
        entityId: claimId,
        details: `Marked item "${claim.found_name}" (Claim #CLM-${1000 + claimId}) as RETURNED to owner.`,
        ipAddress: req.ip
      });
    });

    tx();

    return setFlashRedirect(
      req,
      res,
      '/admin?tab=claims',
      `Item "${claim.found_name}" marked as RETURNED! Both owner and finder notified.`,
      'success'
    );
  } catch (err) {
    console.error('Mark returned error:', err);
    return setFlashRedirect(req, res, '/admin?tab=claims', 'Failed to mark item as returned.', 'error');
  }
}

function dismissMatch(req, res) {
  try {
    const matchId = Number(req.params.id);
    db.prepare("UPDATE matches SET status = 'DISMISSED' WHERE id = ? AND status = 'DETECTED'").run(matchId);
    logActivity({
      userId: req.currentUser.id,
      action: 'MATCH_DISMISSED',
      entityType: 'MATCH',
      entityId: matchId,
      details: `Admin dismissed low-relevance AI match #${matchId}.`,
      ipAddress: req.ip
    });
    return setFlashRedirect(req, res, '/admin?tab=matches', 'AI match dismissed.', 'success');
  } catch (err) {
    console.error('Dismiss match error:', err);
    return setFlashRedirect(req, res, '/admin?tab=matches', 'Could not update match.', 'error');
  }
}

function rerunMatchingEngine(req, res) {
  try {
    const count = runFullDatabaseMatching(db);
    logActivity({
      userId: req.currentUser.id,
      action: 'AI_REINDEX',
      entityType: 'SYSTEM',
      entityId: null,
      details: `Admin triggered full TF-IDF + Cosine Similarity re-scan (${count} active matches refreshed).`,
      ipAddress: req.ip
    });
    return setFlashRedirect(
      req,
      res,
      '/admin?tab=matches',
      `TF-IDF Smart Matcher re-scanned all active reports (${count} matches evaluated).`,
      'success'
    );
  } catch (err) {
    console.error('Rerun matching error:', err);
    return setFlashRedirect(req, res, '/admin?tab=matches', 'Failed to run AI re-scan.', 'error');
  }
}

function toggleUserStatus(req, res) {
  try {
    const targetUserId = Number(req.params.id);
    if (targetUserId === req.currentUser.id) {
      return setFlashRedirect(req, res, '/admin?tab=users', 'You cannot deactivate your own Admin account.', 'error');
    }

    const user = db.prepare('SELECT id, full_name, role, is_active FROM users WHERE id = ?').get(targetUserId);
    if (!user) {
      return setFlashRedirect(req, res, '/admin?tab=users', 'User account not found.', 'error');
    }

    const nextState = user.is_active ? 0 : 1;
    db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(nextState, targetUserId);

    logActivity({
      userId: req.currentUser.id,
      action: nextState ? 'USER_ACTIVATED' : 'USER_SUSPENDED',
      entityType: 'USER',
      entityId: targetUserId,
      details: `Admin ${nextState ? 'reactivated' : 'suspended'} account for ${user.full_name}.`,
      ipAddress: req.ip
    });

    return setFlashRedirect(
      req,
      res,
      '/admin?tab=users',
      `Account for ${user.full_name} is now ${nextState ? 'Active' : 'Suspended'}.`,
      'success'
    );
  } catch (err) {
    console.error('Toggle user error:', err);
    return setFlashRedirect(req, res, '/admin?tab=users', 'Failed to update user account status.', 'error');
  }
}

module.exports = {
  reviewClaim,
  markClaimReturned,
  dismissMatch,
  rerunMatchingEngine,
  toggleUserStatus
};
